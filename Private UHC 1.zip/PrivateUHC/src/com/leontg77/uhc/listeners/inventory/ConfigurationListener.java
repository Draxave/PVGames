package com.leontg77.uhc.listeners.inventory;

import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import com.leontg77.uhc.Game;
import com.leontg77.uhc.InvGUI;
import com.leontg77.uhc.Scoreboards;

public class ConfigurationListener implements Listener {
	
	@SuppressWarnings("unused")
	@EventHandler
    public void onInventoryClick(InventoryClickEvent event) {	
        if (event.getCurrentItem() == null) {
        	return;
        }
        
        Scoreboards board = Scoreboards.getInstance();
		Game game = Game.getInstance();
		
		Inventory inv = event.getInventory();
		ItemStack item = event.getCurrentItem();
		
		if (!inv.getTitle().equals("� �7Configuration")) {
			return;
		}
		
		if(item.getType() == Material.BOOK){
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;

			InvGUI invs = InvGUI.getInstance();
			invs.openScen(player);
		}
		if(item.getType() == Material.NETHER_BRICK){
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;

			InvGUI invs = InvGUI.getInstance();
			invs.openNether(player);
		}
		
		event.setCancelled(true);
		
		if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) {
			return;
		}
		
	}

}

package com.leontg77.uhc.cmds;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import com.leontg77.uhc.InvGUI;
import com.leontg77.uhc.Main;

public class ATPCommand implements CommandExecutor, Listener {

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (!sender.hasPermission("uhc.config")) {
			sender.sendMessage(Main.NO_PERM_MSG); 
			return true;
		}
		if (args.length == 0) {
			if (!(sender instanceof Player)) {
				sender.sendMessage(Main.PREFIX + "Usage: /atp");
				return true;
			}
			
			Player player = (Player) sender;

			InvGUI inv = InvGUI.getInstance();
			inv.openScen(player);
			return true;
		}
		
		return true;
		
	}
	

}

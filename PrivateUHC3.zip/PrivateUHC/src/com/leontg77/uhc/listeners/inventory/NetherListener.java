package com.leontg77.uhc.listeners.inventory;

import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import com.leontg77.uhc.Game;
import com.leontg77.uhc.InvGUI;
import com.leontg77.uhc.Main;
import com.leontg77.uhc.Scoreboards;
import com.leontg77.uhc.utils.PlayerUtils;

public class NetherListener implements Listener {
	
	@SuppressWarnings("unused")
	@EventHandler
    public void onInventoryClick(InventoryClickEvent event) {	
        if (event.getCurrentItem() == null) {
        	return;
        }
        
        Scoreboards board = Scoreboards.getInstance();
		Game game = Game.getInstance();
		
		Inventory inv = event.getInventory();
		ItemStack item = event.getCurrentItem();
		
		if (!inv.getTitle().equals("� �7Nether")) {
			return;
		}
		
		
		event.setCancelled(true);
		
		if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) {
			return;
		}
		
		String name = item.getItemMeta().getDisplayName().substring(2);
		
		if (name.equalsIgnoreCase("Nether")) {
			if (game.nether()) {
				PlayerUtils.broadcast(Main.PREFIX + "Nether has been disabled.");
				game.setNether(false);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				item.setItemMeta(meta);
			} else {
				PlayerUtils.broadcast(Main.PREFIX + "Nether has been enabled.");
				game.setNether(true);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				item.setItemMeta(meta);
			}
			return;
		}
		if (name.equalsIgnoreCase("Ghast drop gold")) {
			if (game.ghastDropGold()) {
				PlayerUtils.broadcast(Main.PREFIX + "Ghasts will now drop ghast tears.");
				game.setGhastDropGold(false);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				item.setItemMeta(meta);
			} else {
				PlayerUtils.broadcast(Main.PREFIX + "Ghasts will now drop gold ingots.");
				game.setGhastDropGold(true);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				item.setItemMeta(meta);
			}
			return;
		}
		
		if (name.equalsIgnoreCase("Golden Melon needs ingots")) {
			if (game.goldenMelonNeedsIngots()) {
				PlayerUtils.broadcast(Main.PREFIX + "Golden Melons now require nuggets.");
				game.setGoldenMelonNeedsIngots(false);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				item.setItemMeta(meta);
			} else {
				PlayerUtils.broadcast(Main.PREFIX + "Golden Melons now require ingots.");
				game.setGoldenMelonNeedsIngots(true);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				item.setItemMeta(meta);
			}
			return;
		}
		if (name.equalsIgnoreCase("Tier 2")) {
			if (game.tier2()) {
				PlayerUtils.broadcast(Main.PREFIX + "Tier 2 has been disabled.");
				game.setTier2(false);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				item.setItemMeta(meta);
			} else {
				PlayerUtils.broadcast(Main.PREFIX + "Tier 2 has been enabled.");
				game.setTier2(true);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				item.setItemMeta(meta);
			}
			return;
		}
		
		if (name.equalsIgnoreCase("Splash")) {
			if (game.splash()) {
				PlayerUtils.broadcast(Main.PREFIX + "Splash has been disabled.");
				game.setSplash(false);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				item.setItemMeta(meta);
			} else {
				PlayerUtils.broadcast(Main.PREFIX + "Splash has been enabled.");
				game.setSplash(true);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				item.setItemMeta(meta);
			}
			return;
		}
		
		if (name.equalsIgnoreCase("Strength")) {
			if (game.strength()) {
				PlayerUtils.broadcast(Main.PREFIX + "Strength has been disabled.");
				game.setStrength(false);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				item.setItemMeta(meta);
			} else {
				PlayerUtils.broadcast(Main.PREFIX + "Strength has been enabled.");
				game.setStrength(true);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				item.setItemMeta(meta);
			}
			return;
		}
		
		if (name.equalsIgnoreCase("Nerfed Strength")) {
			if (game.nerfedStrength()) {
				PlayerUtils.broadcast(Main.PREFIX + "Strength is no longer nerfed.");
				game.setNerfedStrength(false);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				item.setItemMeta(meta);
			} else {
				PlayerUtils.broadcast(Main.PREFIX + "Strength is now nerfed.");
				game.setNerfedStrength(true);
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				item.setItemMeta(meta);
			}
			return;
		}
	
		if(item.getType() == Material.REDSTONE_COMPARATOR && item.hasItemMeta() && item.getItemMeta().hasDisplayName() 
				&& item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �cConfig Menu")){
			
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;

			InvGUI invs = InvGUI.getInstance();
			invs.openConfig(player);
			player.openInventory(InvGUI.getInstance().openConfig(player));

		}
		
		
	}

}

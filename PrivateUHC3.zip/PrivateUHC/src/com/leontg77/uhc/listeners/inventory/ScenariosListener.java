package com.leontg77.uhc.listeners.inventory;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import com.leontg77.uhc.InvGUI;
import com.leontg77.uhc.Main;
import com.leontg77.uhc.scenario.Scenario;
import com.leontg77.uhc.scenario.ScenarioManager;
import com.leontg77.uhc.utils.PlayerUtils;

public class ScenariosListener implements Listener {
	
	@EventHandler
    public void onInventoryClick(InventoryClickEvent event) {	
        if (event.getCurrentItem() == null) {
        	return;
        }
        
		ScenarioManager scen = ScenarioManager.getInstance();
		
		Inventory inv = event.getInventory();
		ItemStack item = event.getCurrentItem();
		String name = item.getItemMeta().getDisplayName().substring(2);
		Scenario scenario = scen.getScenario(item.getItemMeta().getDisplayName().substring(2));
		
		if (!inv.getTitle().equals("� �7Scenarios Page 1")) {
			return;
		}
		

		if(item.getType() == Material.SKULL_ITEM && item.hasItemMeta() && item.getItemMeta().hasDisplayName() 
				&& item.getItemMeta().getDisplayName().equalsIgnoreCase("�7Next Page")){
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;

			InvGUI invs = InvGUI.getInstance();
			invs.openSce(player);
			player.openInventory(InvGUI.getInstance().openScens(player));
		}
		if(item.getType() == Material.REDSTONE_COMPARATOR && item.hasItemMeta() && item.getItemMeta().hasDisplayName() 
				&& item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �cConfig Menu")){
			
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;

			InvGUI invs = InvGUI.getInstance();
			invs.openConfig(player);
			player.openInventory(InvGUI.getInstance().openConfig(player));

		}
		if(item.getType() == Material.BARRIER){
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;
			player.closeInventory();
			
		}
		
		event.setCancelled(true);
		
		if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) {
			return;
		}
		
		
	
		if (name.equalsIgnoreCase("CutClean")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "CutClean has been enabled");
				
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
				
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "CutClean has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			
			return;
		}
		
		if(name.equalsIgnoreCase("BetaZombies")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "BetaZombies has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "BetaZombies has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("SlaveMarket")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "SlaveMarket has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "SlaveMarket has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("NoFall")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "NoFall has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "NoFall has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("GoneFishing")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "GoneFishing has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "GoneFishing has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("SkyHigh")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "SkyHigh has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "SkyHigh has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("FlowerPower")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "FlowerPower has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "FlowerPower has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if (name.equalsIgnoreCase("Diamondless")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "Diamondless has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "Diamondless has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			
			return;
		}
		
		if(name.equalsIgnoreCase("Goldless")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "Goldless has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "Goldless has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("BloodLapis")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "BloodLapis has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "BloodLapis has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("BloodDiamonds")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "BloodDiamonds has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "BloodDiamonds has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("TriplesOres")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "TriplesOres has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "TriplesOres has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("Timebomb")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "Timebomb has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "Timebomb has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("TrainingRabbits")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "TrainingRabbits has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "TrainingRabbits has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if (name.equalsIgnoreCase("Barebones")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "Barebones has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "Barebones has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			
			return;
		}
		
		if(name.equalsIgnoreCase("InfiniteEnchanter")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "InfiniteEnchanter has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "InfiniteEnchanter has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("GoToHell")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "GoToHell has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "GoToHell has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("Kings")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "Kings has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "Kings has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("Captains")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "Captains has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "Captains has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("MysteryTeams")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "MysteryTeams has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "MysteryTeams has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("AssaultAndBattery")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "AssaultAndBattery has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "AssaultAndBattery has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if (name.equalsIgnoreCase("RewardingLongshots")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "RewardingLongshots has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "RewardingLongshots has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			
			return;
		}
		
		if(name.equalsIgnoreCase("Superheroes")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "Superheroes has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "Superheroes has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("Lootcrates")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "Lootcrates has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "Lootcrates has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("Switchhero")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "Switchhero has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "Switchhero has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("BlockRush")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "BlockRush has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "BlockRush has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("DragonRush")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "DragonRush has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "DragonRush has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
		if(name.equalsIgnoreCase("GoldRush")) {
			if(!scenario.isEnabled()) {
				scenario.enable();
				PlayerUtils.broadcast(Main.PREFIX + "GoldRush has been enabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�a" + name);
				meta.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}else {
				scenario.disable();
				PlayerUtils.broadcast(Main.PREFIX + "GoldRush has been disabled");
				
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�c" + name);
				meta.removeEnchant(Enchantment.DAMAGE_UNDEAD);
				meta.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
			return;
		}
			
        
	}
	
	@SuppressWarnings("unused")
	@EventHandler
    public void onInventoryClick1(InventoryClickEvent event) {	
        if (event.getCurrentItem() == null) {
        	return;
        }
        
		ScenarioManager scen = ScenarioManager.getInstance();
		
		Inventory inv = event.getInventory();
		ItemStack item = event.getCurrentItem();
		String name = item.getItemMeta().getDisplayName().substring(2);
		Scenario scenario = scen.getScenario(item.getItemMeta().getDisplayName().substring(2));
		
		if (!inv.getTitle().equals("� �7Scenarios Page 2")) {
			return;
		}
		
		if(item.getType() == Material.SKULL_ITEM && item.hasItemMeta() && item.getItemMeta().hasDisplayName() 
				&& item.getItemMeta().getDisplayName().equalsIgnoreCase("�7Next Page")){
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;

			InvGUI invs = InvGUI.getInstance();
			invs.openSce(player);
			player.openInventory(InvGUI.getInstance().openSce(player));
		}
		if(item.getType() == Material.SKULL_ITEM && item.hasItemMeta() && item.getItemMeta().hasDisplayName() 
				&& item.getItemMeta().getDisplayName().equalsIgnoreCase("�7Last Page")){
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;

			InvGUI invs = InvGUI.getInstance();
			invs.openScen(player);
			player.openInventory(InvGUI.getInstance().openScen(player));
		}
		
		if(item.getType() == Material.BARRIER){
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;
			player.closeInventory();
			
		}
		
		event.setCancelled(true);
		
		if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) {
			return;
		}
		
		

		
	}
	
	@SuppressWarnings("unused")
	@EventHandler
    public void onInventoryClick2(InventoryClickEvent event) {	
        if (event.getCurrentItem() == null) {
        	return;
        }
        
		ScenarioManager scen = ScenarioManager.getInstance();
		
		Inventory inv = event.getInventory();
		ItemStack item = event.getCurrentItem();
		String name = item.getItemMeta().getDisplayName().substring(2);
		Scenario scenario = scen.getScenario(item.getItemMeta().getDisplayName().substring(2));
		
		if (!inv.getTitle().equals("� �7Scenarios Page 3")) {
			return;
		}
		
		if(item.getType() == Material.SKULL_ITEM){
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;

			InvGUI invs = InvGUI.getInstance();
			invs.openScens(player);
			player.openInventory(InvGUI.getInstance().openScens(player));
		}
		
		if(item.getType() == Material.BARRIER){
			Entity sender = event.getWhoClicked();
			Player player = (Player) sender;
			player.closeInventory();
			
		}
		
		event.setCancelled(true);
		
		if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) {
			return;
		}
		
		

		
	}
	
	


}

package com.leontg77.uhc;

import static com.leontg77.uhc.Main.plugin;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;
import java.util.TimeZone;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;

import com.leontg77.uhc.User.Rank;
import com.leontg77.uhc.User.Stat;
import com.leontg77.uhc.scenario.Scenario;
import com.leontg77.uhc.scenario.ScenarioManager;
import com.leontg77.uhc.utils.DateUtils;
import com.leontg77.uhc.utils.GameUtils;
import com.leontg77.uhc.utils.NameUtils;
import com.leontg77.uhc.utils.NumberUtils;
import com.leontg77.uhc.utils.PlayerUtils;

/**
 * The inventory managing class.
 * <p>
 * This class contains methods for opening the selector inventory, game info inventory, hall of fame inventory and player inventories.
 * 
 * @author LeonTG77
 */
public class InvGUI {
	private Settings settings = Settings.getInstance();
	private static InvGUI manager = new InvGUI();
	
	public HashMap<Player, HashMap<Integer, Inventory>> pagesForPlayer = new HashMap<Player, HashMap<Integer, Inventory>>();
	public HashMap<Player, Integer> currentPage = new HashMap<Player, Integer>();

	
	/**
	 * Gets the instance of this class
	 * 
	 * @return The instance.
	 */
	public static InvGUI getInstance() {
		return manager;
	}
	
	public Inventory openStats(Player player, User user) {
		Inventory inv = Bukkit.createInventory(user.getPlayer(), InventoryType.HOPPER, "� �7" + user.getPlayer().getName() + "'s Stats");
		ArrayList<String> lore = new ArrayList<String>(); 
		
		ItemStack general = new ItemStack (Material.SIGN);
		ItemMeta generalMeta = general.getItemMeta();
		generalMeta.setDisplayName("�8� �6General Stats �8�");
		lore.add(" ");
		lore.add("�8� �7Games played: �a" + user.getStat(Stat.GAMESPLAYED));
		lore.add("�8� �7Wins: �a" + user.getStat(Stat.WINS));
		lore.add(" ");
		lore.add("�8� �7Hostile kills: �a" + user.getStat(Stat.HOSTILEMOBKILLS));
		lore.add("�8� �7Animal kills: �a" + user.getStat(Stat.ANIMALKILLS));
		lore.add("�8� �7Damage taken: �a" + (((double) user.getStat(Stat.DAMAGETAKEN)) / 2));
		lore.add(" ");
		generalMeta.setLore(lore);
		general.setItemMeta(generalMeta);
		inv.setItem(0, general);
		lore.clear();
		
		ItemStack pvpmining = new ItemStack (Material.DIAMOND_AXE);
		ItemMeta pvpminingMeta = pvpmining.getItemMeta();
		pvpminingMeta.setDisplayName("�8� �6PvP & Mining Stats �8�");
		lore.add(" ");
		lore.add("�8� �7Highest Arena Killstreak: �a" + user.getStat(Stat.ARENAKILLSTREAK));
		lore.add("�8� �7Highest Killstreak: �a" + user.getStat(Stat.KILLSTREAK));
		lore.add(" ");
		lore.add("�8� �7Kills: �a" + user.getStat(Stat.KILLS));
		lore.add("�8� �7Deaths: �a" + user.getStat(Stat.DEATHS));
		if (user.getStat(Stat.DEATHS) == 0) {
			lore.add("�8� �7KDR: �a" + user.getStat(Stat.KILLS));
		} else {
			lore.add("�8� �7KDR: �a" + user.getStat(Stat.KILLS) / user.getStat(Stat.DEATHS));
		}
		lore.add(" ");
		lore.add("�8� �7Diamonds mined: �a" + user.getStat(Stat.DIAMONDS));
		lore.add("�8� �7Gold mined: �a" + user.getStat(Stat.GOLD));
		lore.add(" ");
		lore.add("�8� �7Arena Kills: �a" + user.getStat(Stat.ARENAKILLS));
		lore.add("�8� �7Arena Deaths: �a" + user.getStat(Stat.ARENADEATHS));
		if (user.getStat(Stat.ARENADEATHS) == 0) {
			lore.add("�8� �7Arena KDR: �a" + user.getStat(Stat.ARENAKILLS));
		} else {
			lore.add("�8� �7Arena KDR: �a" + user.getStat(Stat.ARENAKILLS) / user.getStat(Stat.ARENADEATHS));
		}
		lore.add(" ");
		pvpminingMeta.setLore(lore); 
		pvpminingMeta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
		pvpminingMeta.addEnchant(Enchantment.DURABILITY, 1, true);
		pvpmining.setItemMeta(pvpminingMeta);
		inv.setItem(2, pvpmining);
		lore.clear();
		
		ItemStack misc = new ItemStack (Material.NETHER_STALK);
		ItemMeta miscMeta = misc.getItemMeta();
		miscMeta.setDisplayName("�8� �6Misc Stats �8�");
		lore.add(" ");
		lore.add("�8� �7Golden Apples eaten: �a" + user.getStat(Stat.GOLDENAPPLESEATEN));
		lore.add("�8� �7Golden Heads eaten: �a" + user.getStat(Stat.GOLDENHEADSEATEN));
		lore.add("�8� �7Potions drunk: �a" + user.getStat(Stat.POTIONS));
		lore.add(" ");
		lore.add("�8� �7Nethers entered: �a" + user.getStat(Stat.NETHER));
		lore.add("�8� �7Ends entered: �a" + user.getStat(Stat.END));
		lore.add(" ");
		lore.add("�8� �7Horses tamed: �a" + user.getStat(Stat.HORSESTAMED));
		lore.add("�8� �7Wolves tamed: �a" + user.getStat(Stat.WOLVESTAMED));
		lore.add(" ");
		miscMeta.setLore(lore);
		misc.setItemMeta(miscMeta);
		inv.setItem(4, misc);
		lore.clear();
		
		player.openInventory(inv);
		return inv;
	}
	
	/**
	 * Opens an inventory of all the online players that is playing.
	 * 
	 * @param player the player opening for.
	 * @return The opened inventory.
	 */
	public Inventory openSelector(Player player) {
		ArrayList<Player> list = new ArrayList<Player>(PlayerUtils.getPlayers());
		Inventory inv = null;

		for (Player online : PlayerUtils.getPlayers()) {
			if (Spectator.getInstance().isSpectating(online) || !GameUtils.getGameWorlds().contains(online.getWorld())) {
				list.remove(online);
			}
		}
		
		int pages = ((list.size() / 28) + 1);
		
		pagesForPlayer.put(player, new HashMap<Integer, Inventory>());
		
		for (int current = 1; current <= pages; current++) {
			inv = Bukkit.createInventory(null, 54, "� �7Player Selector");
			
			for (int i = 0; i < 35; i++) {
				if (list.size() < 1) {
					continue;
				}
				
				if (noItem(i)) {
					continue;
				}
				
				Player target = list.remove(0);
				
				ItemStack item = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
				SkullMeta meta = (SkullMeta) item.getItemMeta();
				meta.setDisplayName("�a" + target.getName());
				meta.setLore(Arrays.asList("�7Click to teleport."));
				meta.setOwner(target.getName());
				item.setItemMeta(meta);
				inv.setItem(i, item);
			}
			
			ItemStack nextpage = new ItemStack (Material.ARROW);
			ItemMeta pagemeta = nextpage.getItemMeta();
			pagemeta.setDisplayName(ChatColor.GREEN + "Next page");
			pagemeta.setLore(Arrays.asList("�7Switch to the next page."));
			nextpage.setItemMeta(pagemeta);
			
			ItemStack prevpage = new ItemStack (Material.ARROW);
			ItemMeta prevmeta = prevpage.getItemMeta();
			prevmeta.setDisplayName(ChatColor.GREEN + "Previous page");
			prevmeta.setLore(Arrays.asList("�7Switch to the previous page."));
			prevpage.setItemMeta(prevmeta);
			
			if (current != 1) {
				inv.setItem(47, prevpage);
			}
			
			if (current != pages) {
				inv.setItem(51, nextpage);
			}
			
			pagesForPlayer.get(player).put(current, inv);
		}
		
		inv = pagesForPlayer.get(player).get(1);
		currentPage.put(player, 1);
		
		player.openInventory(inv);
		return inv;
	}

	/**
	 * Opens the inventory of the given target for the given player.
	 * 
	 * @param player player to open for.
	 * @param target the players inv to use.
	 * 
	 * @return The opened inventory.
	 */
	public Inventory openPlayerInventory(final Player player, final Player target) {
		final Inventory inv = Bukkit.getServer().createInventory(target, 54, "� �7" + target.getName() + "'s Inventory");
	
		Main.invsee.put(inv, new BukkitRunnable() {
			public void run() {
				inv.setItem(0, target.getInventory().getHelmet());
				inv.setItem(1, target.getInventory().getChestplate());
				inv.setItem(2, target.getInventory().getLeggings());
				inv.setItem(3, target.getInventory().getBoots());
				inv.setItem(5, target.getItemInHand());
				inv.setItem(6, target.getItemOnCursor());
				
				ItemStack info = new ItemStack (Material.BOOK);
				ItemMeta infoMeta = info.getItemMeta();
				infoMeta.setDisplayName("�8� �6Player Info �8�");
				ArrayList<String> lore = new ArrayList<String>();
				lore.add("�8� �7Name: �a" + target.getName());
				lore.add(" ");
				int health = (int) target.getHealth();
				lore.add("�8� �7Hearts: �6" + (((double) health) / 2) + "�4��");
				lore.add("�8� �7Percent: �6" + NumberUtils.makePercent(target.getHealth()) + "%");
				lore.add("�8� �7Hunger: �6" + (target.getFoodLevel() / 2));
				lore.add("�8� �7Xp level: �6" + target.getLevel());
				lore.add("�8� �7Location: �6x:" + target.getLocation().getBlockX() + ", y:" + target.getLocation().getBlockY() + ", z:" + target.getLocation().getBlockZ() + " (" + target.getWorld().getEnvironment().name().replaceAll("_", "").toLowerCase().replaceAll("normal", "overworld") + ")");
				lore.add(" ");
				lore.add("�8� �cPotion effects:");
				
				if (target.getActivePotionEffects().size() == 0) {
					lore.add("�8� �7None");
				}
				
				for (PotionEffect effects : target.getActivePotionEffects()) {
					lore.add("�8� �7P:�6" + NameUtils.getPotionName(effects.getType()) + " �7T:�6" + (effects.getAmplifier() + 1) + " �7D:�6" + DateUtils.ticksToString(effects.getDuration() / 20));
				}
				
				infoMeta.setLore(lore);
				info.setItemMeta(infoMeta);
				inv.setItem(8, info);
				lore.clear();
				
				for (int i = 9; i < 18; i++) {
					ItemStack glass = new ItemStack (Material.STAINED_GLASS_PANE, 1, (short) 15);
					ItemMeta glassMeta = glass.getItemMeta();
					glassMeta.setDisplayName("�0:>");
					glass.setItemMeta(glassMeta);
					inv.setItem(8, info);
					inv.setItem(i, glass);
				}
				
				int i = 18;
				
				for (ItemStack item : target.getInventory().getContents()) {
					inv.setItem(i, item);
					i++;
				}
				
				player.updateInventory();
			}
		});
		
		Main.invsee.get(inv).runTaskTimer(Main.plugin, 1, 1);
		player.openInventory(inv);
		
		return inv;
	}
	
	/**
	 * Opens an inventory the given hosts hall of fame.
	 * 
	 * @param player the player opening for.
	 * @param host The owner of the hall of fame.
	 * @return The opened inventory.
	 */
	public Inventory openHOF(Player player, String host) {
		Set<String> keys = settings.getHOF().getConfigurationSection(host).getKeys(false);
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		
		ArrayList<String> list = new ArrayList<String>(keys);
		Inventory inv = null;
		
		int pages = ((list.size() / 28) + 1);
		
		pagesForPlayer.put(player, new HashMap<Integer, Inventory>());
		
		for (int current = 1; current <= pages; current++) {
			inv = Bukkit.createInventory(null, 54, "� �7" + host + "'s HoF, Page " + current);
			
			for (int i = 0; i < 35; i++) {
				if (list.size() < 1) {
					continue;
				}
				
				if (noItem(i)) {
					continue;
				}
				
				String target = list.remove(0);
				boolean isSpecial = target.endsWith("50") || target.endsWith("00") || target.endsWith("25") || target.endsWith("75");
				
				ItemStack item = new ItemStack (Material.GOLDEN_APPLE, 1, isSpecial ? (short) 1 : (short) 0);
				ItemMeta meta = item.getItemMeta();
				meta.setDisplayName("�8� �6" + host + "'s #" + target + " �8�");
				
				ArrayList<String> lore = new ArrayList<String>();
				lore.add("�7" + settings.getHOF().getString(host + "." + target + ".date", "N/A"));
				lore.add(" ");
				lore.add("�8� �cWinners:");
				
				for (String winners : settings.getHOF().getStringList(host + "." + target + ".winners")) {
					lore.add("�8� �7" + winners);
				}
				
				lore.add(" ");
				lore.add("�8� �cKills:");
				lore.add("�8� �7" + settings.getHOF().getString(host + "." + target + ".kills", "-1"));
				
				if (!settings.getHOF().getString(host + "." + target + ".teamsize", "FFA").isEmpty()) {
					lore.add(" ");
					lore.add("�8� �cTeamsize:");
					lore.add("�8� �7" + settings.getHOF().getString(host + "." + target + ".teamsize", "FFA"));
				}
				
				lore.add(" ");
				lore.add("�8� �cScenario:");
				
				for (String scenario : settings.getHOF().getString(host + "." + target + ".scenarios", "Vanilla+").split(" ")) {
					lore.add("�8� �7" + scenario);
				}
				
				lore.add(" ");
				meta.setLore(lore);
				item.setItemMeta(meta);
				inv.setItem(i, item);
			}
			
			ItemStack nextpage = new ItemStack (Material.ARROW);
			ItemMeta pagemeta = nextpage.getItemMeta();
			pagemeta.setDisplayName(ChatColor.GREEN + "Next page");
			pagemeta.setLore(Arrays.asList("�7Switch to the next page."));
			nextpage.setItemMeta(pagemeta);
			
			ItemStack prevpage = new ItemStack (Material.ARROW);
			ItemMeta prevmeta = prevpage.getItemMeta();
			prevmeta.setDisplayName(ChatColor.GREEN + "Previous page");
			prevmeta.setLore(Arrays.asList("�7Switch to the previous page."));
			prevpage.setItemMeta(prevmeta);
			
			String name = GameUtils.getHostName(host);
			
			ItemStack head = new ItemStack (Material.SKULL_ITEM, 1, (short) 3);
			SkullMeta headMeta = (SkullMeta) head.getItemMeta();
			headMeta.setDisplayName("�8� �6Host Info �8�");
			headMeta.setOwner(name);
			ArrayList<String> hlore = new ArrayList<String>();
			hlore.add(" ");
			hlore.add("�8� �7Total games hosted: �6" + settings.getHOF().getConfigurationSection(host).getKeys(false).size());
			hlore.add("�8� �7Rank: �6" + NameUtils.fixString(User.get(PlayerUtils.getOfflinePlayer(name)).getRank().name(), false));
			hlore.add(" ");
			hlore.add("�8� �7Host name: �6" + host);
			hlore.add("�8� �7IGN: �6" + name);
			hlore.add(" ");
			headMeta.setLore(hlore);
			head.setItemMeta(headMeta);
			
			inv.setItem(49, head);
			
			if (current != 1) {
				inv.setItem(47, prevpage);
			}
			
			if (current != pages) {
				inv.setItem(51, nextpage);
			}
			
			pagesForPlayer.get(player).put(current, inv);
		}
		
		inv = pagesForPlayer.get(player).get(1);
		currentPage.put(player, 1);
		
		player.openInventory(inv);
		return inv;
	}
	
	/**
	 * Open the config option inventory for the given player.
	 * 
	 * @param player The player opening for.
	 * @return The opened inventory.
	 */
	public Inventory openConfigOptions(Player player) {
		Inventory inv = Bukkit.getServer().createInventory(null, 45, "� �7Game config");
		Game game = Game.getInstance();
		
		ItemStack absorption = new ItemStack (Material.GOLDEN_APPLE);
		ItemMeta absorptionMeta = absorption.getItemMeta();
		absorptionMeta.setDisplayName((game.absorption() ? "�a" : "�c") + "Absorption");
		absorption.setItemMeta(absorptionMeta);
		inv.setItem(0, absorption);
		
		ItemStack heads = new ItemStack (Material.SKULL_ITEM, 1, (short) 3);
		ItemMeta headsMeta = heads.getItemMeta();
		headsMeta.setDisplayName((game.goldenHeads() ? "�a" : "�c") + "Golden Heads");
		heads.setItemMeta(headsMeta);
		inv.setItem(1, heads);
		
		ItemStack pearl = new ItemStack (Material.ENDER_PEARL);
		ItemMeta peralMeta = pearl.getItemMeta();
		peralMeta.setDisplayName((game.goldenHeads() ? "�a" : "�c") + "Pearl Damage");
		pearl.setItemMeta(peralMeta);
		inv.setItem(2, pearl);
		
		ItemStack notchApples = new ItemStack (Material.GOLDEN_APPLE, 1, (short) 1);
		ItemMeta notchMeta = notchApples.getItemMeta();
		notchMeta.setDisplayName((game.notchApples() ? "�a" : "�c") + "Notch Apples");
		notchApples.setItemMeta(notchMeta);
		inv.setItem(3, notchApples);
		
		ItemStack hearts = new ItemStack (Material.INK_SACK, 1, (short) 1);
		ItemMeta heartsMeta = hearts.getItemMeta();
		heartsMeta.setDisplayName((game.heartsOnTab() ? "�a" : "�c") + "Hearts on tab");
		hearts.setItemMeta(heartsMeta);
		inv.setItem(5, hearts);
		
		ItemStack hardcore = new ItemStack (Material.REDSTONE);
		ItemMeta hardcoreMeta = hardcore.getItemMeta();
		hardcoreMeta.setDisplayName((game.hardcoreHearts() ? "�a" : "�c") + "Hardcore Hearts");
		hardcore.setItemMeta(hardcoreMeta);
		inv.setItem(6, hardcore);
		
		ItemStack tab = new ItemStack (Material.SIGN);
		ItemMeta tabMeta = tab.getItemMeta();
		tabMeta.setDisplayName((game.tabShowsHealthColor() ? "�a" : "�c") + "Tab health color");
		tab.setItemMeta(tabMeta);
		inv.setItem(7, tab);
		
		ItemStack rr = new ItemStack (Material.PAINTING);
		ItemMeta rrMeta = rr.getItemMeta();
		rrMeta.setDisplayName((game.isRecordedRound() ? "�a" : "�c") + "Recorded Round");
		rr.setItemMeta(rrMeta);
		inv.setItem(8, rr);
		
		ItemStack nether = new ItemStack (Material.NETHER_STALK);
		ItemMeta netherMeta = nether.getItemMeta();
		netherMeta.setDisplayName((game.nether() ? "�a" : "�c") + "Nether");
		nether.setItemMeta(netherMeta);
		inv.setItem(18, nether);
		
		ItemStack end = new ItemStack (Material.ENDER_PORTAL_FRAME);
		ItemMeta endMeta = end.getItemMeta();
		endMeta.setDisplayName((game.theEnd() ? "�a" : "�c") + "The End");
		end.setItemMeta(endMeta);
		inv.setItem(19, end);
		
		ItemStack strip = new ItemStack (Material.DIAMOND_PICKAXE);
		ItemMeta stripMeta = strip.getItemMeta();
		stripMeta.setDisplayName((game.antiStripmine() ? "�a" : "�c") + "Anti Stripmine");
		strip.setItemMeta(stripMeta);
		inv.setItem(21, strip);
		
		ItemStack death = new ItemStack (Material.BLAZE_ROD);
		ItemMeta deathMeta = death.getItemMeta();
		deathMeta.setDisplayName((game.deathLightning() ? "�a" : "�c") + "Death Lightning");
		death.setItemMeta(deathMeta);
		inv.setItem(22, death);
		
		ItemStack horse = new ItemStack (Material.SADDLE);
		ItemMeta horseMeta = horse.getItemMeta();
		horseMeta.setDisplayName((game.horses() ? "�a" : "�c") + "Horses");
		horse.setItemMeta(horseMeta);
		inv.setItem(24, horse);
		
		ItemStack armor = new ItemStack (Material.IRON_BARDING);
		ItemMeta armorMeta = armor.getItemMeta();
		armorMeta.setDisplayName((game.horseArmor() ? "�a" : "�c") + "Horse Armor");
		armor.setItemMeta(armorMeta);
		inv.setItem(25, armor);
		
		ItemStack healing = new ItemStack (Material.BREAD);
		ItemMeta healingMeta = healing.getItemMeta();
		healingMeta.setDisplayName((game.horseHealing() ? "�a" : "�c") + "Horse Healing");
		healing.setItemMeta(healingMeta);
		inv.setItem(26, healing);
		
		ItemStack shears = new ItemStack (Material.SHEARS);
		ItemMeta shearsMeta = shears.getItemMeta();
		shearsMeta.setDisplayName((game.shears() ? "�a" : "�c") + "Shears");
		shears.setItemMeta(shearsMeta);
		inv.setItem(36, shears);
		
		ItemStack ghast = new ItemStack (Material.GHAST_TEAR);
		ItemMeta ghastMeta = ghast.getItemMeta();
		ghastMeta.setDisplayName((game.ghastDropGold() ? "�a" : "�c") + "Ghast drop gold");
		ghast.setItemMeta(ghastMeta);
		inv.setItem(37, ghast);
		
		ItemStack melon = new ItemStack (Material.SPECKLED_MELON);
		ItemMeta melonMeta = melon.getItemMeta();
		melonMeta.setDisplayName((game.goldenMelonNeedsIngots() ? "�a" : "�c") + "Golden Melon needs ingots");
		melon.setItemMeta(melonMeta);
		inv.setItem(38, melon);
		
		ItemStack tier2 = new ItemStack (Material.GLOWSTONE_DUST);
		ItemMeta tier2Meta = tier2.getItemMeta();
		tier2Meta.setDisplayName((game.tier2() ? "�a" : "�c") + "Tier 2");
		tier2.setItemMeta(tier2Meta);
		inv.setItem(41, tier2);
		
		ItemStack splash = new ItemStack (Material.POTION, 1, (short) 16424);
		ItemMeta splashMeta = splash.getItemMeta();
		splashMeta.setDisplayName((game.splash() ? "�a" : "�c") + "Splash");
		splash.setItemMeta(splashMeta);
		inv.setItem(42, splash);
		
		ItemStack str = new ItemStack (Material.BLAZE_POWDER);
		ItemMeta strMeta = str.getItemMeta();
		strMeta.setDisplayName((game.strength() ? "�a" : "�c") + "Strength");
		str.setItemMeta(strMeta);
		inv.setItem(43, str);
		
		ItemStack nerf = new ItemStack (Material.POTION, 1, (short) 8233);
		ItemMeta nerfMeta = nerf.getItemMeta();
		nerfMeta.setDisplayName((game.nerfedStrength() ? "�a" : "�c") + "Nerfed Strength");
		nerf.setItemMeta(nerfMeta);
		inv.setItem(44, nerf);
		
		ItemStack liv = new ItemStack(Material.BOOK);
		ItemMeta livr = liv.getItemMeta();
		livr.setDisplayName("Scenerios");
		liv.setItemMeta(livr);
		inv.setItem(13, liv);
				
		player.openInventory(inv);
		
		return inv;
	}
	
	public Inventory openConfig(Player player) {
		 
        Inventory invs = Bukkit.getServer().createInventory(null, 54, "� �7Configuration");
        
        @SuppressWarnings("deprecation")
		ItemStack a = new ItemStack(160, 1,(short)8);
        ItemMeta ar = a.getItemMeta();
        ar.setDisplayName("�0>");
        a.setItemMeta(ar);
        invs.setItem(0, a);
        invs.setItem(1, a);
        invs.setItem(2, a);
        invs.setItem(3, a);
        invs.setItem(4, a);
        invs.setItem(5, a);
        invs.setItem(6, a);
        invs.setItem(7, a);
        invs.setItem(8, a);
        invs.setItem(9, a);
        invs.setItem(17, a);
        invs.setItem(18, a);
        invs.setItem(26, a);
        invs.setItem(27, a);
        invs.setItem(35, a);
        invs.setItem(36, a);
        invs.setItem(44, a);
        invs.setItem(45, a);
        invs.setItem(46, a);
        invs.setItem(47, a);
        invs.setItem(48, a);
        invs.setItem(50, a);
        invs.setItem(51, a);
        invs.setItem(52, a);
        invs.setItem(53, a);
        
        ItemStack clos = new ItemStack(Material.BARRIER);
        ItemMeta close = clos.getItemMeta();
        close.setDisplayName("�cClose");
        clos.setItemMeta(close);
        invs.setItem(49, clos);
        
        ItemStack b = new ItemStack(Material.BOOK);
        ItemMeta br = b.getItemMeta();
        br.setDisplayName("�eScenarios");
        b.setItemMeta(br);
        invs.setItem(22, b);
        
        ItemStack n = new ItemStack(Material.NETHER_BRICK);
        ItemMeta nr = n .getItemMeta();
        nr.setDisplayName("�cNether");
        n.setItemMeta(nr);
        invs.setItem(24, n);
        
        player.openInventory(invs);
                
        return invs;       
	}
	
	public Inventory openScen(Player player) {
		 
        Inventory invs = Bukkit.getServer().createInventory(null, 54, "� �7Scenarios Page 1");
        ScenarioManager scen = ScenarioManager.getInstance();
        
        if(scen.getScenario("CutClean").isEnabled()) {
        ItemStack cutcl = new ItemStack(Material.IRON_INGOT, 1);
        ItemMeta cutclr = cutcl.getItemMeta();
        cutclr.setDisplayName("�aCutClean");
        cutclr.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		cutclr.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        cutcl.setItemMeta(cutclr);       
        invs.setItem(10, cutcl);       
        }else {
        ItemStack cutcl = new ItemStack(Material.IRON_INGOT, 0);
        ItemMeta cutclr = cutcl.getItemMeta();
        cutclr.setDisplayName("�cCutClean");
        cutclr.removeEnchant(Enchantment.DAMAGE_UNDEAD);
		cutclr.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
        cutcl.setItemMeta(cutclr);
        
        invs.setItem(10, cutcl);
        }
       
        if(scen.getScenario("BetaZombies").isEnabled()) {
        ItemStack betz = new ItemStack(Material.FEATHER, 1);
        ItemMeta betaz = betz.getItemMeta();
        betaz.setDisplayName("�aBetaZombies");
        betaz.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		betaz.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        betz.setItemMeta(betaz);
        invs.setItem(11, betz);
        }else {
        	ItemStack betz = new ItemStack(Material.FEATHER, 0);
            ItemMeta betaz = betz.getItemMeta();
            betaz.setDisplayName("�cBetaZombies");
            betaz.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		betaz.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            betz.setItemMeta(betaz);
            invs.setItem(11, betz);
            }
       
        if(scen.getScenario("SlaveMarket").isEnabled()) {
        ItemStack slv = new ItemStack(Material.EMERALD, 1);
        ItemMeta slvm = slv.getItemMeta();
        slvm.setDisplayName("�aSlaveMarket");
        slvm.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		slvm.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        slv.setItemMeta(slvm);
        invs.setItem(12, slv);
        }else {
        	ItemStack slv = new ItemStack(Material.EMERALD, 0);
            ItemMeta slvm = slv.getItemMeta();
            slvm.setDisplayName("�cSlaveMarket");
            slvm.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		slvm.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            slv.setItemMeta(slvm);
            invs.setItem(12, slv);
            }
       
        if(scen.getScenario("NoFall").isEnabled()) {
        ItemStack nf = new ItemStack(Material.DIAMOND_BOOTS, 1);
        ItemMeta nfl = nf.getItemMeta();
        nfl.setDisplayName("�aNoFall");
        nfl.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		nfl.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        nf.setItemMeta(nfl);
        invs.setItem(13, nf);
        }else {
        	ItemStack nf = new ItemStack(Material.DIAMOND_BOOTS, 0);
            ItemMeta nfl = nf.getItemMeta();
            nfl.setDisplayName("�cNoFall");
            nfl.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		nfl.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            nf.setItemMeta(nfl);
            invs.setItem(13, nf);
            }
       
        if(scen.getScenario("GoneFishing").isEnabled()) {
        ItemStack gf = new ItemStack(Material.FISHING_ROD, 1);
        ItemMeta gfn = gf.getItemMeta();
        gfn.setDisplayName("�aGoneFishing");
        gfn.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		gfn.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        gf.setItemMeta(gfn);
        invs.setItem(14, gf);
        }else {
        	ItemStack gf = new ItemStack(Material.FISHING_ROD, 0);
            ItemMeta gfn = gf.getItemMeta();
            gfn.setDisplayName("�cGoneFishing");
            gfn.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		gfn.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            gf.setItemMeta(gfn);
            invs.setItem(14, gf);
            }
       
        if(scen.getScenario("SkyHigh").isEnabled()) {
        ItemStack sh = new ItemStack(Material.LADDER, 1);
        ItemMeta shg = sh.getItemMeta();
        shg.setDisplayName("�aSkyHigh");
        shg.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		shg.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        sh.setItemMeta(shg);
        invs.setItem(15, sh);
        }else {
        	ItemStack sh = new ItemStack(Material.LADDER, 0);
            ItemMeta shg = sh.getItemMeta();
            shg.setDisplayName("�cSkyHigh");
            shg.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		shg.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            sh.setItemMeta(shg);
            invs.setItem(15, sh);
            }
       
        if(scen.getScenario("FlowerPower").isEnabled()) {
        ItemStack fp = new ItemStack(Material.YELLOW_FLOWER, 1);
        ItemMeta fpd = fp.getItemMeta();
        fpd.setDisplayName("�aFlowerPower");
        fpd.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		fpd.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        fp.setItemMeta(fpd);
        invs.setItem(16, fp);
        }else {
        	ItemStack fp = new ItemStack(Material.YELLOW_FLOWER, 0);
            ItemMeta fpd = fp.getItemMeta();
            fpd.setDisplayName("�cFlowerPower");
            fpd.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		fpd.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            fp.setItemMeta(fpd);
            invs.setItem(16, fp);
            }
        
        if(scen.getScenario("Diamondless").isEnabled()) {
        ItemStack dl = new ItemStack(Material.DIAMOND_ORE, 1);
        ItemMeta dls = dl.getItemMeta();
        dls.setDisplayName("�aDiamondless");
        dls.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		dls.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        dl.setItemMeta(dls);
        invs.setItem(19, dl);
        }else {
        	ItemStack dl = new ItemStack(Material.DIAMOND_ORE, 0);
            ItemMeta dls = dl.getItemMeta();
            dls.setDisplayName("�cDiamondless");
            dls.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		dls.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            dl.setItemMeta(dls);
            invs.setItem(19, dl);
            }
       
        if(scen.getScenario("Goldless").isEnabled()) {
        ItemStack gl = new ItemStack(Material.GOLD_ORE, 1);
        ItemMeta gls = gl.getItemMeta();
        gls.setDisplayName("�aGoldless");
        gls.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		gls.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        gl.setItemMeta(gls);
        invs.setItem(20, gl);
        }else {
        	ItemStack gl = new ItemStack(Material.GOLD_ORE, 0);
            ItemMeta gls = gl.getItemMeta();
            gls.setDisplayName("�cGoldless");
            gls.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		gls.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            gl.setItemMeta(gls);
            invs.setItem(20, gl);
            }
       
        if(scen.getScenario("BloodLapis").isEnabled()) {
        ItemStack bl = new ItemStack(Material.LAPIS_ORE, 1);
        ItemMeta bls = bl.getItemMeta();
        bls.setDisplayName("�aBloodLapis");
        bls.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		bls.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        bl.setItemMeta(bls);        
        invs.setItem(21, bl);
        }else {
        	ItemStack bl = new ItemStack(Material.LAPIS_ORE, 0);
            ItemMeta bls = bl.getItemMeta();
            bls.setDisplayName("�cBloodLapis");
            bls.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		bls.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            bl.setItemMeta(bls);
            invs.setItem(21, bl);
            }
       
        if(scen.getScenario("BloodDiamonds").isEnabled()) {
        ItemStack dlr = new ItemStack(Material.DIAMOND, 1);
        ItemMeta dlsr = dlr.getItemMeta();
        dlsr.setDisplayName("�aBloodDiamonds");
        dlsr.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		dlsr.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        dlr.setItemMeta(dlsr);
        invs.setItem(22, dlr);
        }else {
        	ItemStack dlr = new ItemStack(Material.DIAMOND, 0);
            ItemMeta dlsr = dlr.getItemMeta();
            dlsr.setDisplayName("�cBloodDiamonds");
            dlsr.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		dlsr.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            dlr.setItemMeta(dlsr);
            invs.setItem(22, dlr);
            }
       
        
        ItemStack to = new ItemStack(Material.IRON_ORE);
        ItemMeta tos = to.getItemMeta();
        tos.setDisplayName("�aTriplesOres");
        to.setItemMeta(tos);
        invs.setItem(23, to);
        
       
        if(scen.getScenario("TimeBomb").isEnabled()) {
        ItemStack tb = new ItemStack(Material.TNT, 1);
        ItemMeta tbs = tb.getItemMeta();
        tbs.setDisplayName("�aTimeBomb");
        tbs.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		tbs.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        tb.setItemMeta(tbs);
        invs.setItem(24, tb);
        }else {
        	ItemStack tb = new ItemStack(Material.TNT, 0);
            ItemMeta tbs = tb.getItemMeta();
            tbs.setDisplayName("�cTimeBomb");
            tbs.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		tbs.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            tb.setItemMeta(tbs);
            invs.setItem(24, tb);
            }
       
        if(scen.getScenario("TrainingRabbits").isEnabled()) {
        ItemStack tr = new ItemStack(Material.RABBIT_FOOT, 1);
        ItemMeta trs = tr.getItemMeta();
        trs.setDisplayName("�aTrainingRabbits");
        trs.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		trs.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        tr.setItemMeta(trs);
        invs.setItem(25, tr);
        }else {
        	ItemStack tr = new ItemStack(Material.RABBIT_FOOT, 0);
            ItemMeta trs = tr.getItemMeta();
            trs.setDisplayName("�cTrainingRabbits");
            trs.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		trs.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            tr.setItemMeta(trs);
            invs.setItem(25, tr);
            }
        
        if(scen.getScenario("Barebones").isEnabled()) {
        ItemStack bb = new ItemStack(Material.BONE, 1);
        ItemMeta bbs = bb.getItemMeta();
        bbs.setDisplayName("�aBarebones");
        bbs.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		bbs.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        bb.setItemMeta(bbs);
        invs.setItem(28, bb);
        }else {
        	ItemStack bb = new ItemStack(Material.BONE, 0);
            ItemMeta bbs = bb.getItemMeta();
            bbs.setDisplayName("�cBarebones");
            bbs.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		bbs.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            bb.setItemMeta(bbs);
            invs.setItem(28, bb);
            }
       
        if(scen.getScenario("InfiniteEnchanter").isEnabled()) {
        ItemStack ifs = new ItemStack(Material.BOOKSHELF, 1);
        ItemMeta ife = ifs.getItemMeta();
        ife.setDisplayName("�aInfiniteEnchanter");
        ife.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		ife.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        ifs.setItemMeta(ife);
        invs.setItem(29, ifs);
        }else {
        	ItemStack ifs = new ItemStack(Material.BOOKSHELF, 0);
            ItemMeta ife = ifs.getItemMeta();
            ife.setDisplayName("�cInfiniteEnchanter");
            ife.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		ife.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            ifs.setItemMeta(ife);
            invs.setItem(29, ifs);
            }
       
        if(scen.getScenario("GoToHell").isEnabled()) {
        ItemStack gt = new ItemStack(Material.NETHER_BRICK, 1);
        ItemMeta gth = gt.getItemMeta();
        gth.setDisplayName("�aGoToHell");
        gth.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		gth.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        gt.setItemMeta(gth);
        invs.setItem(30, gt);
        }else {
        	ItemStack gt = new ItemStack(Material.NETHER_BRICK, 0);
            ItemMeta gth = gt.getItemMeta();
            gth.setDisplayName("�cGoToHell");
            gth.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		gth.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            gt.setItemMeta(gth);
            invs.setItem(30, gt);
            }
       
        if(scen.getScenario("Kings").isEnabled()) {
        ItemStack kg = new ItemStack(Material.GOLD_BLOCK, 1);
        ItemMeta kgs = kg.getItemMeta();
        kgs.setDisplayName("�aKings");
        kgs.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		kgs.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        kg.setItemMeta(kgs);
        invs.setItem(31, kg);
        }else {
        	ItemStack kg = new ItemStack(Material.GOLD_BLOCK, 0);
            ItemMeta kgs = kg.getItemMeta();
            kgs.setDisplayName("�cKings");
            kgs.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		kgs.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            kg.setItemMeta(kgs);
            invs.setItem(31, kg);
            }
       
        if(scen.getScenario("Captains").isEnabled()) {
        ItemStack cp = new ItemStack(Material.DIAMOND_BLOCK, 1);
        ItemMeta cps = cp.getItemMeta();
        cps.setDisplayName("�aCaptains");
        cps.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		cps.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        cp.setItemMeta(cps);
        invs.setItem(32, cp);
        }else {
        	ItemStack cp = new ItemStack(Material.DIAMOND_BLOCK, 0);
            ItemMeta cps = cp.getItemMeta();
            cps.setDisplayName("�cCaptains");
            cps.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		cps.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            cp.setItemMeta(cps);
            invs.setItem(32, cp);
            }
       
        if(scen.getScenario("MysteryTeams").isEnabled()) {
        ItemStack mt = new ItemStack(Material.BANNER, 1);
        ItemMeta mts = mt.getItemMeta();
        mts.setDisplayName("�aMysteryTeams");
        mts.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		mts.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        mt.setItemMeta(mts);
        invs.setItem(33, mt);
        }else {
        	ItemStack mt = new ItemStack(Material.BANNER, 0);
            ItemMeta mts = mt.getItemMeta();
            mts.setDisplayName("�cMysteryTeams");
            mts.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		mts.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            mt.setItemMeta(mts);
            invs.setItem(33, mt);
            }
       
        if(scen.getScenario("AssaultAndBattery").isEnabled()) {
        ItemStack ab = new ItemStack(Material.WOOD_SWORD, 1);
        ItemMeta aab = ab.getItemMeta();
        aab.setDisplayName("�aAssaultAndBattery");
        aab.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		aab.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        ab.setItemMeta(aab);
        invs.setItem(34, ab);
        }else {
        	ItemStack ab = new ItemStack(Material.WOOD_SWORD, 0);
            ItemMeta aab = ab.getItemMeta();
            aab.setDisplayName("�cAssaultAndBattery");
            aab.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		aab.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            ab.setItemMeta(aab);
            invs.setItem(34, ab);
            }
        
        if(scen.getScenario("RewardingLongshots").isEnabled()) {
        ItemStack rew = new ItemStack(Material.ARROW, 1);
        ItemMeta rewl = rew.getItemMeta();
        rewl.setDisplayName("�aRewardingLongshots");
        rewl.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		rewl.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        rew.setItemMeta(rewl);
        invs.setItem(37, rew);
        }else {
        	ItemStack rew = new ItemStack(Material.ARROW, 0);
            ItemMeta rewl = rew.getItemMeta();
            rewl.setDisplayName("�cRewardingLongshots");
            rewl.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		rewl.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            rew.setItemMeta(rewl);
            invs.setItem(37, rew);
            }
       
        if(scen.getScenario("Superheroes").isEnabled()) {
        ItemStack suh = new ItemStack(Material.POTION, 1);
        ItemMeta suhs = suh.getItemMeta();
        suhs.setDisplayName("�aSuperheroes");
        suhs.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		suhs.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        suh.setItemMeta(suhs);
        invs.setItem(38, suh);
        }else {
        	ItemStack suh = new ItemStack(Material.POTION, 0);
            ItemMeta suhs = suh.getItemMeta();
            suhs.setDisplayName("�cSuperheroes");
            suhs.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		suhs.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            suh.setItemMeta(suhs);
            invs.setItem(38, suh);
            }
       
        if(scen.getScenario("Lootcrates").isEnabled()) {
        ItemStack lc = new ItemStack(Material.CHEST, 1);
        ItemMeta lcs = lc.getItemMeta();
        lcs.setDisplayName("�aLootcrates");
        lcs.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		lcs.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        lc.setItemMeta(lcs);
        invs.setItem(39, lc);
        }else {
        	ItemStack lc = new ItemStack(Material.CHEST, 0);
            ItemMeta lcs = lc.getItemMeta();
            lcs.setDisplayName("�cLootcrates");
            lcs.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		lcs.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            lc.setItemMeta(lcs);
            invs.setItem(39, lc);
            }
       
        if(scen.getScenario("Switchhero").isEnabled()) {
        ItemStack sha = new ItemStack(Material.SNOW_BALL, 1);
        ItemMeta shsa = sha.getItemMeta();
        shsa.setDisplayName("�aSwitchhero");
        shsa.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		shsa.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        sha.setItemMeta(shsa);
        invs.setItem(40, sha);
        }else {
        	ItemStack sha = new ItemStack(Material.SNOW_BALL, 0);
            ItemMeta shsa = sha.getItemMeta();
            shsa.setDisplayName("�cSwitchhero");
            shsa.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		shsa.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            sha.setItemMeta(shsa);
            invs.setItem(40, sha);
            }
       
        if(scen.getScenario("BlockRush").isEnabled()) {
        ItemStack br = new ItemStack(Material.BEACON, 1);
        ItemMeta brs = br.getItemMeta();
        brs.setDisplayName("�aBlockRush");
        brs.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		brs.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        br.setItemMeta(brs);
        invs.setItem(41, br);
        }else {
        	ItemStack br = new ItemStack(Material.BEACON, 0);
            ItemMeta brs = br.getItemMeta();
            brs.setDisplayName("�cBlockRush");
            brs.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		brs.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            br.setItemMeta(brs);
            invs.setItem(41, br);
            }
       
        if(scen.getScenario("DragonRush").isEnabled()) {
        ItemStack dr = new ItemStack(Material.DRAGON_EGG, 1);
        ItemMeta drs = dr.getItemMeta();
        drs.setDisplayName("�aDragonRush");
        drs.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		drs.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        dr.setItemMeta(drs);
        invs.setItem(42, dr);
        }else {
        	ItemStack dr = new ItemStack(Material.DRAGON_EGG, 0);
            ItemMeta drs = dr.getItemMeta();
            drs.setDisplayName("�cDragonRush");
            drs.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		drs.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            dr.setItemMeta(drs);
            invs.setItem(42, dr);
            }
       
        if(scen.getScenario("GoldRush").isEnabled()) {
        ItemStack gr = new ItemStack(Material.GOLD_INGOT, 1);
        ItemMeta grs = gr.getItemMeta();
        grs.setDisplayName("�aGoldRush");
        grs.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		grs.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        gr.setItemMeta(grs);
        invs.setItem(43, gr);
        }else {
        	ItemStack gr = new ItemStack(Material.GOLD_INGOT, 0);
            ItemMeta grs = gr.getItemMeta();
            grs.setDisplayName("�cGoldRush");
            grs.removeEnchant(Enchantment.DAMAGE_UNDEAD);
    		grs.removeItemFlags(ItemFlag.HIDE_ENCHANTS);
            gr.setItemMeta(grs);
            invs.setItem(43, gr);
            }
       
        @SuppressWarnings("deprecation")
		ItemStack a = new ItemStack(160, 1,(short)8);
        ItemMeta ar = a.getItemMeta();
        ar.setDisplayName("�0>");
        a.setItemMeta(ar);
        invs.setItem(0, a);
        invs.setItem(1, a);
        invs.setItem(2, a);
        invs.setItem(3, a);
        invs.setItem(4, a);
        invs.setItem(5, a);
        invs.setItem(6, a);
        invs.setItem(7, a);
        invs.setItem(8, a);
        invs.setItem(9, a);
        invs.setItem(17, a);
        invs.setItem(18, a);
        invs.setItem(26, a);
        invs.setItem(27, a);
        invs.setItem(35, a);
        invs.setItem(36, a);
        invs.setItem(44, a);
        invs.setItem(45, a);
        invs.setItem(46, a);
        invs.setItem(47, a);
        invs.setItem(48, a);
        invs.setItem(50, a);
        invs.setItem(52, a);
        invs.setItem(53, a);
       
        ItemStack clos = new ItemStack(Material.BARRIER);
        ItemMeta close = clos.getItemMeta();
        close.setDisplayName("�cClose");
        clos.setItemMeta(close);
        invs.setItem(49, clos);
        
        ItemStack Item_Skull = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
    	SkullMeta Meta_Skull = (SkullMeta) Item_Skull.getItemMeta();
        Meta_Skull.setOwner("MHF_ArrowRight");
        Meta_Skull.setDisplayName("�7Next Page");
        Item_Skull.setItemMeta(Meta_Skull);
        invs.setItem(51, Item_Skull);
        
        
        ItemStack pd = new ItemStack(Material.REDSTONE_COMPARATOR);
        ItemMeta pdr = pd.getItemMeta();
        pdr.setDisplayName("�8� �cConfig Menu");
		pdr.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		pdr.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		pd.setItemMeta(pdr);
        invs.setItem(47, pd);

        player.openInventory(invs);
 
        return invs;
 
 
    }
	
	
	public Inventory openScens(Player player) {
		
		Inventory invs = Bukkit.getServer().createInventory(null, 54, "� �7Scenarios Page 2");
        ScenarioManager scen = ScenarioManager.getInstance();
		
		@SuppressWarnings("deprecation")
		ItemStack a = new ItemStack(160, 1,(short)8);
        ItemMeta ar = a.getItemMeta();
        ar.setDisplayName("�0>");
        a.setItemMeta(ar);
        invs.setItem(0, a);
        invs.setItem(1, a);
        invs.setItem(2, a);
        invs.setItem(3, a);
        invs.setItem(4, a);
        invs.setItem(5, a);
        invs.setItem(6, a);
        invs.setItem(7, a);
        invs.setItem(8, a);
        invs.setItem(9, a);
        invs.setItem(17, a);
        invs.setItem(18, a);
        invs.setItem(26, a);
        invs.setItem(27, a);
        invs.setItem(35, a);
        invs.setItem(36, a);
        invs.setItem(44, a);
        invs.setItem(45, a);
        invs.setItem(46, a);
        invs.setItem(48, a);
        invs.setItem(50, a);
        invs.setItem(52, a);
        invs.setItem(53, a);
       
        if(scen.getScenario("Assassins").isEnabled()) {
        ItemStack cutcl = new ItemStack(Material.IRON_FENCE);
        ItemMeta cutclr = cutcl.getItemMeta();
        cutclr.setDisplayName("�aAssassins");
        cutcl.setItemMeta(cutclr);
        invs.setItem(10, cutcl);       
        }else {
        ItemStack cutcl = new ItemStack(Material.IRON_FENCE);
        ItemMeta cutclr = cutcl.getItemMeta();
        cutclr.setDisplayName("�cAssassins");
        cutcl.setItemMeta(cutclr);
        invs.setItem(10, cutcl);
        }
       
        if(scen.getScenario("Moles").isEnabled()) {
        ItemStack betz = new ItemStack(Material.IRON_FENCE);
        ItemMeta betaz = betz.getItemMeta();
        betaz.setDisplayName("�aMoles");
        betz.setItemMeta(betaz);
        invs.setItem(11, betz);
        }else {
        	ItemStack betz = new ItemStack(Material.IRON_FENCE);
            ItemMeta betaz = betz.getItemMeta();
            betaz.setDisplayName("�cMoles");
            betz.setItemMeta(betaz);
            invs.setItem(11, betz);
            }
       
        if(scen.getScenario("TeamHealth").isEnabled()) {
        ItemStack slv = new ItemStack(Material.IRON_FENCE);
        ItemMeta slvm = slv.getItemMeta();
        slvm.setDisplayName("�aTeamHealth");
        slv.setItemMeta(slvm);
        invs.setItem(12, slv);
        }else {
        	ItemStack slv = new ItemStack(Material.IRON_FENCE);
            ItemMeta slvm = slv.getItemMeta();
            slvm.setDisplayName("�cTeamHealth");
            slv.setItemMeta(slvm);
            invs.setItem(12, slv);
            }
       
        if(scen.getScenario("VengefulSpirits").isEnabled()) {
        ItemStack nf = new ItemStack(Material.IRON_FENCE);
        ItemMeta nfl = nf.getItemMeta();
        nfl.setDisplayName("�aVengefulSpirits");
        nf.setItemMeta(nfl);
        invs.setItem(13, nf);
        }else {
        	ItemStack nf = new ItemStack(Material.IRON_FENCE);
            ItemMeta nfl = nf.getItemMeta();
            nfl.setDisplayName("�cVengefulSpirits");
            nf.setItemMeta(nfl);
            invs.setItem(13, nf);
            }
       
        if(scen.getScenario("SkyClean").isEnabled()) {
        ItemStack gf = new ItemStack(Material.IRON_FENCE);
        ItemMeta gfn = gf.getItemMeta();
        gfn.setDisplayName("�aSkyClean");
        gf.setItemMeta(gfn);
        invs.setItem(14, gf);
        }else {
        	ItemStack gf = new ItemStack(Material.IRON_FENCE);
            ItemMeta gfn = gf.getItemMeta();
            gfn.setDisplayName("�cSkyClean");
            gf.setItemMeta(gfn);
            invs.setItem(14, gf);
            }
       
        if(scen.getScenario("Pyrophobia").isEnabled()) {
        ItemStack sh = new ItemStack(Material.IRON_FENCE);
        ItemMeta shg = sh.getItemMeta();
        shg.setDisplayName("�aPyrophobia");
        sh.setItemMeta(shg);
        invs.setItem(15, sh);
        }else {
        	ItemStack sh = new ItemStack(Material.IRON_FENCE);
            ItemMeta shg = sh.getItemMeta();
            shg.setDisplayName("�cPyrophobia");
            sh.setItemMeta(shg);
            invs.setItem(15, sh);
            }
       
        if(scen.getScenario("PotentialHearts").isEnabled()) {
        ItemStack fp = new ItemStack(Material.IRON_FENCE);
        ItemMeta fpd = fp.getItemMeta();
        fpd.setDisplayName("�aPotentialHearts");
        fp.setItemMeta(fpd);
        invs.setItem(16, fp);
        }else {
        	ItemStack fp = new ItemStack(Material.IRON_FENCE);
            ItemMeta fpd = fp.getItemMeta();
            fpd.setDisplayName("�cPotentialHearts");
            fp.setItemMeta(fpd);
            invs.setItem(16, fp);
            }
        
        if(scen.getScenario("MeleeFun").isEnabled()) {
        ItemStack dl = new ItemStack(Material.IRON_FENCE);
        ItemMeta dls = dl.getItemMeta();
        dls.setDisplayName("�aMeleeFun");
        dl.setItemMeta(dls);
        invs.setItem(19, dl);
        }else {
        	ItemStack dl = new ItemStack(Material.IRON_FENCE);
            ItemMeta dls = dl.getItemMeta();
            dls.setDisplayName("�cMeleeFun");
            dl.setItemMeta(dls);
            invs.setItem(19, dl);
            }
       
        if(scen.getScenario("Genie").isEnabled()) {
        ItemStack gl = new ItemStack(Material.IRON_FENCE);
        ItemMeta gls = gl.getItemMeta();
        gls.setDisplayName("�aGenie");
        gl.setItemMeta(gls);
        invs.setItem(20, gl);
        }else {
        	ItemStack gl = new ItemStack(Material.IRON_FENCE);
            ItemMeta gls = gl.getItemMeta();
            gls.setDisplayName("�cGenie");
            gl.setItemMeta(gls);
            invs.setItem(20, gl);
            }
       
        if(scen.getScenario("NightmareMode").isEnabled()) {
        ItemStack bl = new ItemStack(Material.IRON_FENCE);
        ItemMeta bls = bl.getItemMeta();
        bls.setDisplayName("�aNightmareMode");
        bl.setItemMeta(bls);
        invs.setItem(21, bl);
        }else {
        	ItemStack bl = new ItemStack(Material.IRON_FENCE);
            ItemMeta bls = bl.getItemMeta();
            bls.setDisplayName("�cNightmareMode");
            bl.setItemMeta(bls);
            invs.setItem(21, bl);
            }
       
        if(scen.getScenario("NoSprint").isEnabled()) {
        ItemStack dlr = new ItemStack(Material.IRON_FENCE);
        ItemMeta dlsr = dlr.getItemMeta();
        dlsr.setDisplayName("�aNoSprint");
        dlr.setItemMeta(dlsr);
        invs.setItem(22, dlr);
        }else {
        	ItemStack dlr = new ItemStack(Material.IRON_FENCE);
            ItemMeta dlsr = dlr.getItemMeta();
            dlsr.setDisplayName("�cNoSprint");
            dlr.setItemMeta(dlsr);
            invs.setItem(22, dlr);
            }
       
        if(scen.getScenario("EnchantParanoia").isEnabled()) {
        ItemStack to = new ItemStack(Material.IRON_FENCE);
        ItemMeta tos = to.getItemMeta();
        tos.setDisplayName("�aEnchantParanoia");
        to.setItemMeta(tos);
        invs.setItem(23, to);
        }else {
            ItemStack to = new ItemStack(Material.IRON_FENCE);
            ItemMeta tos = to.getItemMeta();
            tos.setDisplayName("�cEnchantParanoia");
            to.setItemMeta(tos);
            invs.setItem(23, to);
            }
        
       
        if(scen.getScenario("BestBTC").isEnabled()) {
        ItemStack tb = new ItemStack(Material.IRON_FENCE);
        ItemMeta tbs = tb.getItemMeta();
        tbs.setDisplayName("�aBestBTC");
        tb.setItemMeta(tbs);
        invs.setItem(24, tb);
        }else {
        	ItemStack tb = new ItemStack(Material.IRON_FENCE);
            ItemMeta tbs = tb.getItemMeta();
            tbs.setDisplayName("�cBestBTC");
            tb.setItemMeta(tbs);
            invs.setItem(24, tb);
            }
       
        if(scen.getScenario("BiomeParanoia").isEnabled()) {
        ItemStack tr = new ItemStack(Material.IRON_FENCE);
        ItemMeta trs = tr.getItemMeta();
        trs.setDisplayName("�aBiomeParanoia");
        tr.setItemMeta(trs);
        invs.setItem(25, tr);
        }else {
        	ItemStack tr = new ItemStack(Material.IRON_FENCE);
            ItemMeta trs = tr.getItemMeta();
            trs.setDisplayName("�cBiomeParanoia");
            tr.setItemMeta(trs);
            invs.setItem(25, tr);
            }
        
        if(scen.getScenario("LAFS").isEnabled()) {
        ItemStack bb = new ItemStack(Material.IRON_FENCE);
        ItemMeta bbs = bb.getItemMeta();
        bbs.setDisplayName("�aLAFS");
        bb.setItemMeta(bbs);
        invs.setItem(28, bb);
        }else {
        	ItemStack bb = new ItemStack(Material.IRON_FENCE);
            ItemMeta bbs = bb.getItemMeta();
            bbs.setDisplayName("�cLAFS");
            bb.setItemMeta(bbs);
            invs.setItem(28, bb);
            }
       
        if(scen.getScenario("Compensation").isEnabled()) {
        ItemStack ifs = new ItemStack(Material.IRON_FENCE);
        ItemMeta ife = ifs.getItemMeta();
        ife.setDisplayName("�aCompensation");
        ifs.setItemMeta(ife);
        invs.setItem(29, ifs);
        }else {
        	ItemStack ifs = new ItemStack(Material.IRON_FENCE);
            ItemMeta ife = ifs.getItemMeta();
            ife.setDisplayName("�cCompensation");
            ifs.setItemMeta(ife);
            invs.setItem(29, ifs);
            }
       
        if(scen.getScenario("PotentialPermanent").isEnabled()) {
        ItemStack gt = new ItemStack(Material.IRON_FENCE);
        ItemMeta gth = gt.getItemMeta();
        gth.setDisplayName("�aPotentialPermanent");
        gt.setItemMeta(gth);
        invs.setItem(30, gt);
        }else {
        	ItemStack gt = new ItemStack(Material.IRON_FENCE);
            ItemMeta gth = gt.getItemMeta();
            gth.setDisplayName("�cPotentialPermanent");
            gt.setItemMeta(gth);
            invs.setItem(30, gt);
            }
       
        if(scen.getScenario("Backpacks").isEnabled()) {
        ItemStack kg = new ItemStack(Material.IRON_FENCE);
        ItemMeta kgs = kg.getItemMeta();
        kgs.setDisplayName("�aBackpacks");
        kg.setItemMeta(kgs);
        invs.setItem(31, kg);
        }else {
        	ItemStack kg = new ItemStack(Material.IRON_FENCE);
            ItemMeta kgs = kg.getItemMeta();
            kgs.setDisplayName("�cBackpacks");
            kg.setItemMeta(kgs);
            invs.setItem(31, kg);
            }
       
        if(scen.getScenario("SlimyCrack").isEnabled()) {
        ItemStack cp = new ItemStack(Material.IRON_FENCE);
        ItemMeta cps = cp.getItemMeta();
        cps.setDisplayName("�aSlimyCrack");
        cp.setItemMeta(cps);
        invs.setItem(32, cp);
        }else {
        	ItemStack cp = new ItemStack(Material.IRON_FENCE);
            ItemMeta cps = cp.getItemMeta();
            cps.setDisplayName("�cSlimyCrack");
            cp.setItemMeta(cps);
            invs.setItem(32, cp);
            }
       
        if(scen.getScenario("Permakill").isEnabled()) {
        ItemStack mt = new ItemStack(Material.IRON_FENCE);
        ItemMeta mts = mt.getItemMeta();
        mts.setDisplayName("�aPermakill");
        mt.setItemMeta(mts);
        invs.setItem(33, mt);
        }else {
        	ItemStack mt = new ItemStack(Material.IRON_FENCE);
            ItemMeta mts = mt.getItemMeta();
            mts.setDisplayName("�cPermakill");
            mt.setItemMeta(mts);
            invs.setItem(33, mt);
            }
       
        if(scen.getScenario("100Hearts").isEnabled()) {
        ItemStack ab = new ItemStack(Material.IRON_FENCE);
        ItemMeta aab = ab.getItemMeta();
        aab.setDisplayName("�a100Hearts");
        ab.setItemMeta(aab);
        invs.setItem(34, ab);
        }else {
        	ItemStack ab = new ItemStack(Material.IRON_FENCE);
            ItemMeta aab = ab.getItemMeta();
            aab.setDisplayName("�c100Hearts");
            ab.setItemMeta(aab);
            invs.setItem(34, ab);
            }
        
        if(scen.getScenario("Fallout").isEnabled()) {
        ItemStack rew = new ItemStack(Material.IRON_FENCE);
        ItemMeta rewl = rew.getItemMeta();
        rewl.setDisplayName("�aFallout");
        rew.setItemMeta(rewl);
        invs.setItem(37, rew);
        }else {
        	ItemStack rew = new ItemStack(Material.IRON_FENCE);
            ItemMeta rewl = rew.getItemMeta();
            rewl.setDisplayName("�cFallout");
            rew.setItemMeta(rewl);
            invs.setItem(37, rew);
            }
       
        if(scen.getScenario("Astrophobia").isEnabled()) {
        ItemStack suh = new ItemStack(Material.IRON_FENCE);
        ItemMeta suhs = suh.getItemMeta();
        suhs.setDisplayName("�aAstrophobia");
        suh.setItemMeta(suhs);
        invs.setItem(38, suh);
        }else {
        	ItemStack suh = new ItemStack(Material.IRON_FENCE);
            ItemMeta suhs = suh.getItemMeta();
            suhs.setDisplayName("�cAstrophobia");
            suh.setItemMeta(suhs);
            invs.setItem(38, suh);
            }
       
        if(scen.getScenario("SharedHealth").isEnabled()) {
        ItemStack lc = new ItemStack(Material.IRON_FENCE);
        ItemMeta lcs = lc.getItemMeta();
        lcs.setDisplayName("�aSharedHealth");
        lc.setItemMeta(lcs);
        invs.setItem(39, lc);
        }else {
        	ItemStack lc = new ItemStack(Material.IRON_FENCE);
            ItemMeta lcs = lc.getItemMeta();
            lcs.setDisplayName("�cSharedHealth");
            lc.setItemMeta(lcs);
            invs.setItem(39, lc);
            }
       
        if(scen.getScenario("Cryophobia").isEnabled()) {
        ItemStack sha = new ItemStack(Material.IRON_FENCE);
        ItemMeta shsa = sha.getItemMeta();
        shsa.setDisplayName("�aCryophobia");
        sha.setItemMeta(shsa);
        invs.setItem(40, sha);
        }else {
        	ItemStack sha = new ItemStack(Material.IRON_FENCE);
            ItemMeta shsa = sha.getItemMeta();
            shsa.setDisplayName("�cCryophobia");
            sha.setItemMeta(shsa);
            invs.setItem(40, sha);
            }
       
        if(scen.getScenario("BestPVE").isEnabled()) {
        ItemStack br = new ItemStack(Material.IRON_FENCE);
        ItemMeta brs = br.getItemMeta();
        brs.setDisplayName("�aBestPVE");
        br.setItemMeta(brs);
        invs.setItem(41, br);
        }else {
        	ItemStack br = new ItemStack(Material.IRON_FENCE);
            ItemMeta brs = br.getItemMeta();
            brs.setDisplayName("�cBestPVE");
            br.setItemMeta(brs);
            invs.setItem(41, br);
            }
       
        if(scen.getScenario("Inventors").isEnabled()) {
        ItemStack dr = new ItemStack(Material.IRON_FENCE);
        ItemMeta drs = dr.getItemMeta();
        drs.setDisplayName("�aInventors");
        dr.setItemMeta(drs);
        invs.setItem(42, dr);
        }else {
        	ItemStack dr = new ItemStack(Material.IRON_FENCE);
            ItemMeta drs = dr.getItemMeta();
            drs.setDisplayName("�cInventors");
            dr.setItemMeta(drs);
            invs.setItem(42, dr);
            }
       
        if(scen.getScenario("Voidscape").isEnabled()) {
        ItemStack gr = new ItemStack(Material.IRON_FENCE);
        ItemMeta grs = gr.getItemMeta();
        grs.setDisplayName("�aVoidscape");
        gr.setItemMeta(grs);
        invs.setItem(43, gr);
        }else {
        	ItemStack gr = new ItemStack(Material.IRON_FENCE);
            ItemMeta grs = gr.getItemMeta();
            grs.setDisplayName("�cVoidscape");
            gr.setItemMeta(grs);
            invs.setItem(43, gr);
            }
        
        
        
        
        ItemStack clos = new ItemStack(Material.BARRIER);
        ItemMeta close = clos.getItemMeta();
        close.setDisplayName("�cClose");
        clos.setItemMeta(close);
        invs.setItem(49, clos);
        
        ItemStack Item_Skull = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
    	SkullMeta Meta_Skull = (SkullMeta) Item_Skull.getItemMeta();
        Meta_Skull.setOwner("MHF_ArrowRight");
        Meta_Skull.setDisplayName("�7Next Page");
        Item_Skull.setItemMeta(Meta_Skull);
        invs.setItem(51, Item_Skull);
        
        Meta_Skull.setOwner("MHF_ArrowLeft");
        Meta_Skull.setDisplayName("�7Last Page");
        Item_Skull.setItemMeta(Meta_Skull);
        invs.setItem(47, Item_Skull);
        
        player.openInventory(invs);
		
		return invs;	
		
	}
	
   public Inventory openSce(Player player) {
		
		Inventory invs = Bukkit.getServer().createInventory(null, 54, "� �7Scenarios Page 3");
		
		@SuppressWarnings("deprecation")
		ItemStack a = new ItemStack(160, 1,(short)8);
        ItemMeta ar = a.getItemMeta();
        ar.setDisplayName("�0>");
        a.setItemMeta(ar);
        invs.setItem(0, a);
        invs.setItem(1, a);
        invs.setItem(2, a);
        invs.setItem(3, a);
        invs.setItem(4, a);
        invs.setItem(5, a);
        invs.setItem(6, a);
        invs.setItem(7, a);
        invs.setItem(8, a);
        invs.setItem(9, a);
        invs.setItem(17, a);
        invs.setItem(18, a);
        invs.setItem(26, a);
        invs.setItem(27, a);
        invs.setItem(35, a);
        invs.setItem(36, a);
        invs.setItem(44, a);
        invs.setItem(45, a);
        invs.setItem(46, a);
        invs.setItem(48, a);
        invs.setItem(50, a);
        invs.setItem(51, a);
        invs.setItem(52, a);
        invs.setItem(53, a);
       
        ItemStack clos = new ItemStack(Material.BARRIER);
        ItemMeta close = clos.getItemMeta();
        close.setDisplayName("�cClose");
        clos.setItemMeta(close);
        invs.setItem(49, clos);
        
        ItemStack Item_Skull = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
    	SkullMeta Meta_Skull = (SkullMeta) Item_Skull.getItemMeta();
        Meta_Skull.setOwner("MHF_ArrowLeft");
        Meta_Skull.setDisplayName("�7Last Page");
        Item_Skull.setItemMeta(Meta_Skull);
        invs.setItem(47, Item_Skull);
        
        player.openInventory(invs);
		
		return invs;	
		
	}
   
   @SuppressWarnings("deprecation")
public Inventory openNether(final Player player) {
	  
	   final Inventory inv = Bukkit.getServer().createInventory(null, 45, "� �7Nether");
	   Game game = Game.getInstance();
	   
	   ItemStack nether = new ItemStack (Material.NETHERRACK);
		ItemMeta netherMeta = nether.getItemMeta();
		netherMeta.setDisplayName((game.nether() ? "�a" : "�c") + "Nether");
		nether.setItemMeta(netherMeta);
		inv.setItem(22, nether);
		
		ItemStack ghast = new ItemStack (Material.GHAST_TEAR);
		ItemMeta ghastMeta = ghast.getItemMeta();
		ghastMeta.setDisplayName((game.ghastDropGold() ? "�a" : "�c") + "Ghast drop gold");
		ghast.setItemMeta(ghastMeta);
		inv.setItem(14, ghast);
		
		ItemStack melon = new ItemStack (Material.SPECKLED_MELON);
		ItemMeta melonMeta = melon.getItemMeta();
		melonMeta.setDisplayName((game.goldenMelonNeedsIngots() ? "�a" : "�c") + "Golden Melon needs ingots");
		melon.setItemMeta(melonMeta);
		inv.setItem(32, melon);
		
		ItemStack tier2 = new ItemStack (Material.GLOWSTONE_DUST);
		ItemMeta tier2Meta = tier2.getItemMeta();
		tier2Meta.setDisplayName((game.tier2() ? "�a" : "�c") + "Tier 2");
		tier2.setItemMeta(tier2Meta);
		inv.setItem(10, tier2);
		
		ItemStack splash = new ItemStack (Material.POTION, 1, (short) 16424);
		ItemMeta splashMeta = splash.getItemMeta();
		splashMeta.setDisplayName((game.splash() ? "�a" : "�c") + "Splash");
		splash.setItemMeta(splashMeta);
		inv.setItem(28, splash);
		
		ItemStack str = new ItemStack (Material.BLAZE_POWDER);
		ItemMeta strMeta = str.getItemMeta();
		strMeta.setDisplayName((game.strength() ? "�a" : "�c") + "Strength");
		str.setItemMeta(strMeta);
		inv.setItem(12, str);
		
		ItemStack nerf = new ItemStack (Material.POTION, 1, (short) 8233);
		ItemMeta nerfMeta = nerf.getItemMeta();
		nerfMeta.setDisplayName((game.nerfedStrength() ? "�a" : "�c") + "Nerfed Strength");
		nerf.setItemMeta(nerfMeta);
		inv.setItem(30, nerf);
		
		ItemStack a = new ItemStack(160, 1,(short)8);
        ItemMeta ar = a.getItemMeta();
        ar.setDisplayName("�0>");
        a.setItemMeta(ar);
        inv.setItem(0, a);
        inv.setItem(1, a);
        inv.setItem(2, a);
        inv.setItem(3, a);
        inv.setItem(4, a);
        inv.setItem(5, a);
        inv.setItem(6, a);
        inv.setItem(7, a);
        inv.setItem(8, a);
        inv.setItem(9, a);
        inv.setItem(17, a);
        inv.setItem(18, a);
        inv.setItem(26, a);
        inv.setItem(27, a);
        inv.setItem(35, a);
        inv.setItem(36, a);
        inv.setItem(37, a);
        inv.setItem(38, a);
        inv.setItem(39, a);
        inv.setItem(41, a);
        inv.setItem(42, a);
        inv.setItem(43, a);
        inv.setItem(44, a);
        
        ItemStack pd = new ItemStack(Material.REDSTONE_COMPARATOR);
        ItemMeta pdr = pd.getItemMeta();
        pdr.setDisplayName("�8� �cConfig Menu");
		pdr.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		pdr.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		pd.setItemMeta(pdr);
        inv.setItem(40, pd);
	   
	   player.openInventory(inv);
	   
	   return inv;
	   
   }
   
   
	
	/**
	 * Opens the game information inventory.
	 * 
	 * @param player player to open for.
	 * @return The opened inventory.
	 */
	
	public Inventory openGameInfo(final Player player) {
		final Inventory inv = Bukkit.getServer().createInventory(null, 45, "� �7Game Information");
		final ArrayList<String> lore = new ArrayList<String>();
		final Game game = Game.getInstance();
		
		ItemStack general = new ItemStack (Material.SIGN);
		ItemMeta generalMeta = general.getItemMeta();
		generalMeta.setDisplayName("�8� �6General Info �8�");
		lore.add(" ");;
		lore.add("�8� �7Teaming in the arena: �cNot Allowed.");
		lore.add("�8� �7Starter food: �cNone.");
		lore.add(" ");
		lore.add("�8� �7Towering: �aAllowed, but come down at meetup.");
		lore.add("�8� �7Forting: �aAllowed before meetup.");
		lore.add(" ");
		lore.add("�8� �7You can follow our twitter @ArcticUHC to find");
		lore.add(" �7out when our next games are.");
		lore.add(" ");
		lore.add("�8� �7Final heal is 20 seconds after start, ");
		lore.add(" �7no more are given after that.");
		lore.add(" ");
		lore.add("�8� �7Our UHC plugin is custom coded by LeonTG77.");
		lore.add(" ");
		generalMeta.setLore(lore);
		general.setItemMeta(generalMeta);
		inv.setItem(0, general);
		lore.clear();
		
		ItemStack chat = new ItemStack (Material.PAPER);
		ItemMeta chatMeta = chat.getItemMeta();
		chatMeta.setDisplayName("�8� �6Chat Rules �8�");
		lore.add(" ");
		lore.add("�8� �7Excessive rage: �eKick.");
		lore.add(" ");
		lore.add("�8� �7Talking other languages in chat: �cMute.");
		lore.add("�8� �7Excessive Swearing: �cMute.");
		lore.add("�8� �7Homophobic: �cMute.");
		lore.add("�8� �7Spamming: �cMute.");
		lore.add("�8� �7Insults: �cMute.");
		lore.add("�8� �7Racism: �cMute.");
		lore.add(" ");
		lore.add("�8� �7Helpop abuse: �4Ban.");
		lore.add("�8� �7Disrespect: �4Ban.");
		lore.add(" ");
		lore.add("�8� �7Spoiling when alive: �aAllowed.");
		lore.add("�8� �7Spoiling when dead: �cNot allowed.");
		lore.add(" ");
		chatMeta.setLore(lore);
		chat.setItemMeta(chatMeta);
		inv.setItem(2, chat);
		lore.clear();
		
		ItemStack pvp = new ItemStack (Material.IRON_SWORD);
		ItemMeta pvpMeta = pvp.getItemMeta();
		pvpMeta.setDisplayName("�8� �6PvP Rules �8�");
		lore.add(" ");
		lore.add("�8� �7iPvP: �cNot Allowed before pvp.");
		lore.add("�8� �7Team Killing: " + ((GameUtils.getTeamSize().startsWith("r") || GameUtils.getTeamSize().isEmpty()) && !ScenarioManager.getInstance().getScenario("Moles").isEnabled() ? "�cNot Allowed." : "�aAllowed."));
		lore.add("�8� �7Stalking: �aAllowed. �c(Not excessive)");
		lore.add("�8� �7Stealing: �aAllowed.");
		lore.add("�8� �7Crossteaming: �cNot Allowed.");
		lore.add(" ");
		pvpMeta.setLore(lore);
		pvpMeta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		pvp.setItemMeta(pvpMeta);
		inv.setItem(4, pvp);
		lore.clear();
		
		ItemStack mining = new ItemStack (Material.DIAMOND_PICKAXE);
		ItemMeta miningMeta = mining.getItemMeta();
		miningMeta.setDisplayName("�8� �6Mining Rules �8�");
		lore.add(" ");
		if (game.antiStripmine()) {
			lore.add("�8� �4IMPORTANT:");
			lore.add("�8� �7Gold and Diamonds only spawn in caves.");
			lore.add(" ");
			lore.add("�8� �7Stripmining: �aAllowed.");
			lore.add("�8� �7Branchmining: �aAllowed.");
			lore.add("�8� �7Pokeholing: �aAllowed.");
			lore.add("�8� �7Blastmining: �aAllowed.");
			lore.add("�8� �7Staircasing: �aAllowed.");
			lore.add("�8� �7Rollercoastering: �aAllowed.");
			lore.add("�8� �7Digging to sounds: �aAllowed.");
			lore.add("�8� �7Digging to entities: �aAllowed.");
			lore.add("�8� �7Digging to players: �aAllowed.");
			lore.add(" ");
		} else {
			lore.add("�8� �4Info:");
			lore.add("�8� �7AntiStripmine is disabled.");
			lore.add(" ");
			lore.add("�8� �7Stripmining: �cNot Allowed.");
			lore.add("�8� �7Branchmining: �cNot Allowed.");
			lore.add("�8� �7Pokeholing: �cNot Allowed.");
			lore.add("�8� �7Blastmining: �aAllowed.");
			lore.add("�8� �7Staircasing: �aAllowed.");
			lore.add("�8� �7Rollercoastering: �aAllowed.");
			lore.add("�8� �7Digging to sounds: �aAllowed.");
			lore.add("�8� �7Digging to entities: �aAllowed.");
			lore.add("�8� �7Digging to players: �cOnly if you see them.");
			lore.add(" ");
		}
		miningMeta.setLore(lore);
		miningMeta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		mining.setItemMeta(miningMeta);
		inv.setItem(6, mining);
		lore.clear();
		
		ItemStack misc = new ItemStack (Material.NETHER_STAR);
		ItemMeta miscMeta = misc.getItemMeta();
		miscMeta.setDisplayName("�8� �6Misc. Rules �8�");
		lore.add(" ");
		lore.add("�8� �7Suiciding in random team games: �cNot Allowed.");
		lore.add("�8� �7TS in random teams games: �cRequired.");
		lore.add(" ");
		lore.add("�8� �7Xray/Cavefinder: �cNot Allowed.");
		lore.add("�8� �7Hacked Client: �cNot Allowed.");
		lore.add("�8� �7Fast Break: �cNot Allowed.");
		lore.add(" ");
		lore.add("�8� �7F3+A Spam: �cNot Allowed.");
		lore.add("�8� �7Full Bright: �aAllowed.");
		lore.add(" ");
		lore.add("�8� �7Benefitting: �4Ban.");
		lore.add("�8� �7Bug abuse: �4Ban.");
		lore.add("�8� �7PvP Log: �4Ban.");
		lore.add("�8� �7PvE Log: �4Ban.");
		lore.add(" ");
		miscMeta.setLore(lore);
		misc.setItemMeta(miscMeta);
		inv.setItem(8, misc);
		lore.clear();
		
		ItemStack staff = new ItemStack (Material.SKULL_ITEM, 1, (short) 3);
		SkullMeta staffMeta = (SkullMeta) staff.getItemMeta();
		staffMeta.setDisplayName("�8� �6Staff �8�");
		
		ItemStack commands = new ItemStack (Material.BANNER, 1, (short) 1);
		ItemMeta commandsMeta = commands.getItemMeta();
		commandsMeta.setDisplayName("�8� �6Useful commands �8�");
		lore.add(" ");
		lore.add("�a/uhc �8� �7�oView this menu :o");
		lore.add("�a/helpop �8� �7�oAsk for help by the staff.");
		lore.add("�a/post �8� �7�oGet a link to the matchpost.");
		lore.add("�a/team �8� �7�oView the team help menu.");
		lore.add("�a/scen �8� �7�oView the enabled scenarios.");
		lore.add("�a/timeleft �8� �7�oView the timer.");
		lore.add("�a/border �8� �7�oView the current border size.");
		lore.add("�a/hof �8� �7�oView the hall of fame.");
		lore.add("�a/lag �8� �7�oView the server performance.");
		lore.add("�a/ms �8� �7�oView your or someones ping.");
		lore.add("�a/list �8� �7�oView online players.");
		lore.add("�a/pm �8� �7�oTalk in team chat.");
		lore.add("�a/tl �8� �7�oTell your team your coords.");
		lore.add(" ");
		commandsMeta.setLore(lore);
		commands.setItemMeta(commandsMeta);
		inv.setItem(21, commands);
		lore.clear();
		
		ItemStack scenario = new ItemStack (Material.BANNER, 1, (short) 14);
		ItemMeta scenarioMeta = scenario.getItemMeta();
		scenarioMeta.setDisplayName("�8� �6Enabled Scenarios �8�");
		lore.add(" ");
		lore.add("�8� �cScenarios:");
		if (ScenarioManager.getInstance().getEnabledScenarios().isEmpty()) {
			lore.add("�8� �7None!");
		}
		for (Scenario scen : ScenarioManager.getInstance().getEnabledScenarios()) {
			lore.add("�8� �7" + scen.getName());
		}
		lore.add(" ");
		lore.add("�8� �7Use �a/scen �7to view info about the scenarios.");
		lore.add(" ");
		scenarioMeta.setLore(lore);
		scenario.setItemMeta(scenarioMeta);
		inv.setItem(23, scenario);
		lore.clear();
		
		ItemStack nether = new ItemStack (Material.NETHER_STALK);
		ItemMeta netherMeta = nether.getItemMeta();
		netherMeta.setDisplayName("�8� �6Nether Info �8�");
		lore.add(" ");
		lore.add("�8� �7Nether: " + (game.nether() ? "�aEnabled." : "�cDisabled."));
		lore.add("�8� �7The End: " + (game.theEnd() ? "�aEnabled." : "�cDisabled."));
		lore.add(" ");
		if (game.nether()) {
			lore.add("�8� �7Trapping: " + (game.theEnd() ? "�cNot allowed." : "�aAllowed."));
			lore.add("�8� �7Camping: �aAllowed.");
			lore.add(" ");
			lore.add("�8� �7Strength: " + (game.strength() ? (game.nerfedStrength() ? "�cNerfed" : "�aVanilla") : "�cDisabled"));
			lore.add("�8� �7Tier 2: " + (game.tier2() ? "�aEnabled." : "�cDisabled."));
			lore.add("�8� �7Splash: " + (game.splash() ? "�aEnabled." : "�cDisabled."));
			lore.add(" ");
			lore.add("�8� �7Golden Melon: �6" + (game.goldenMelonNeedsIngots() ? "Gold Ingots." : "Golden Nuggets."));
			lore.add("�8� �7Ghast Drop: �6" + (game.ghastDropGold() ? "Gold Ingot." : "Ghast Tear."));
			lore.add(" ");
		}
		netherMeta.setLore(lore);
		nether.setItemMeta(netherMeta);
		inv.setItem(36, nether);
		lore.clear();
		
		ItemStack healing = new ItemStack (Material.GOLDEN_APPLE);
		ItemMeta healingMeta = healing.getItemMeta();
		healingMeta.setDisplayName("�8� �6Healing Info �8�");
		lore.add(" ");
		lore.add("�8� �7Absorption: " + (game.absorption() ? "�aEnabled." : "�cDisabled."));
		lore.add("�8� �7Golden Heads: " + (game.goldenHeads() ? "�aEnabled." : "�cDisabled."));
		if (game.goldenHeads()) {
			lore.add("�8� �7Heads Heal: �6" + game.goldenHeadsHeal() + " hearts.");
		}
		lore.add("�8� �7Notch Apples: " + (game.notchApples() ? "�aEnabled." : "�cDisabled."));
		lore.add(" ");
		healingMeta.setLore(lore);
		healing.setItemMeta(healingMeta);
		inv.setItem(38, healing);
		lore.clear();
		
		ItemStack rates = new ItemStack (Material.FLINT);
		ItemMeta ratesMeta = rates.getItemMeta();
		ratesMeta.setDisplayName("�8� �6Rates Info �8�");
		lore.add(" ");
		lore.add("�8� �7Apple Rates: �6" + game.getAppleRates() + "%");
		lore.add("�8� �7Shears: " + (game.shears() ? "�aWork." : "�cDoes not work.") + "");
		lore.add("�8� �7Flint Rates: �6" + game.getFlintRates() + "%");
		lore.add(" ");
		lore.add("�8� �7Mob Rates: �6Vanilla.");
		lore.add("�8� �7Ore Rates: �6Vanilla.");
		lore.add("�8� �7Cave Rates: �6Vanilla.");
		lore.add(" ");
		lore.add("�8� �7Witch Potion: �6If poisoned 100%, if not 30%");
		lore.add(" ");
		ratesMeta.setLore(lore);
		rates.setItemMeta(ratesMeta);
		inv.setItem(40, rates);
		lore.clear();
		
		ItemStack horse = new ItemStack (Material.SADDLE);
		ItemMeta horseMeta = horse.getItemMeta();
		horseMeta.setDisplayName("�8� �6Horse Info �8�");
		lore.add(" ");
		lore.add("�8� �7Horses: " + (game.horses() ? "�aEnabled." : "�cDisabled."));
		if (game.horses()) {
			lore.add("�8� �7Horse Healing: " + (game.horseHealing() ? "�aEnabled." : "�cDisabled."));
			lore.add("�8� �7Horse Armor: " + (game.horseArmor() ? "�aEnabled." : "�cDisabled."));
		}
		lore.add(" ");
		horseMeta.setLore(lore);
		horse.setItemMeta(horseMeta);
		inv.setItem(42, horse);
		lore.clear();
		
		ItemStack miscI = new ItemStack (Material.ENDER_PEARL);
		ItemMeta miscIMeta = miscI.getItemMeta();
		miscIMeta.setDisplayName("�8� �6Misc. Info �8�");
		lore.add(" ");
		lore.add("�8� �7Enderpearl Damage: " + (game.pearlDamage() ? "�aEnabled, deals 1 heart." : "�cDisabled."));
		lore.add("�8� �7Death Lightning: " + (game.deathLightning() ? "�aEnabled." : "�cDisabled."));
		lore.add("�8� �7Saturation Fix: �aEnabled.");
		lore.add(" ");
		lore.add("�8� �7Border shrinks: �6" + NameUtils.fixString(game.getBorderShrink().getPreText(), false) + game.getBorderShrink().name().toLowerCase() + ".");
		lore.add("�8� �7The border will kill you if you go outside!");
		lore.add(" ");
		lore.add("�8� �7At meetup you can do everything you want");
		lore.add("�8� �7as long as you are inside the border and");
		lore.add("�8� �7on the surface, border can shrink to 100x100.");
		lore.add(" ");
		miscIMeta.setLore(lore);
		miscI.setItemMeta(miscIMeta);
		inv.setItem(44, miscI);
		lore.clear();
		
		File folder = new File(plugin.getDataFolder() + File.separator + "users" + File.separator);
		
		StringBuilder staffs = new StringBuilder();
		StringBuilder owners = new StringBuilder();
		StringBuilder hosts = new StringBuilder();
		StringBuilder specs = new StringBuilder();
		
		ArrayList<String> hostL = new ArrayList<String>();
		ArrayList<String> staffL = new ArrayList<String>();
		ArrayList<String> specL = new ArrayList<String>();
		
		int i = 1;
		int j = 0;
		
		for (File file : folder.listFiles()) {
			FileConfiguration config = YamlConfiguration.loadConfiguration(file);

			if (config.getString("rank").equals(Rank.ADMIN.name())) {
				hostL.add(config.getString("username"));
			}

			if (config.getString("rank").equals(Rank.HOST.name())) {
				hostL.add(config.getString("username"));
			}
			
			if (config.getString("rank").equals(Rank.TRIAL.name())) {
				hostL.add(config.getString("username"));
			}
			
			if (config.getString("rank").equals(Rank.STAFF.name())) {
				staffL.add(config.getString("username"));
			}
			
			if (config.getString("rank").equals(Rank.SPEC.name())) {
				specL.add(config.getString("username"));
			}
		}
		
		for (String sL : hostL) {
			if (hosts.length() > 0) {
				if (hostL.size() == i) {
					hosts.append(" and ");
				} else {
					hosts.append(", ");
				}
			}
			
			if (j == 2) {
				hosts.append("-");
				j = 0;
			} else {
				j++;
			}
			
			hosts.append(sL);
			i++;
		}
		
		i = 1;
		j = 0;
		
		for (String sL : staffL) {
			if (staffs.length() > 0) {
				if (staffL.size() == i) {
					staffs.append(" and ");
				} else {
					staffs.append(", ");
				}
			}
			
			if (j == 2) {
				staffs.append("-");
				j = 0;
			} else {
				j++;
			}
			
			staffs.append(sL);
			i++;
		}
		
		i = 1;
		j = 0;
		
		for (String pL : specL) {
			if (specs.length() > 0) {
				if (specL.size() == i) {
					specs.append(" and ");
				} else {
					specs.append(", ");
				}
			}
			
			if (j == 2) {
				specs.append("-");
				j = 0;
			} else {
				j++;
			}
			
			specs.append(pL);
			i++;
		}
		
		i = 1;
		j = 0;
		
		for (OfflinePlayer ops : Bukkit.getServer().getOperators()) {
			if (owners.length() > 0) {
				if (Bukkit.getOperators().size() == i) {
					owners.append(" and ");
				} else {
					owners.append(", ");
				}
			}
			
			if (j == 2) {
				hosts.append("-");
				j = 0;
			} else {
				j++;
			}
			
			owners.append(ops.getName());
			i++;
		}
		
		lore.add(" ");
		lore.add("�8� �4Owners:");
		for (String split : owners.toString().split("-")) {
			lore.add("�8� �7" + split);
		}
		lore.add(" ");
		lore.add("�8� �4Hosts:");
		for (String split : hosts.toString().split("-")) {
			lore.add("�8� �7" + split);
		}
		lore.add(" ");
		lore.add("�8� �cStaff:");
		for (String split : staffs.toString().split("-")) {
			lore.add("�8� �7" + split);
		}
		lore.add(" ");
		lore.add("�8� �7Specs:");
		for (String split : specs.toString().split("-")) {
			lore.add("�8� �7" + split);
		}
		lore.add(" ");
		staffMeta.setLore(lore);
		staffMeta.setOwner("LeonTG77");
		staff.setItemMeta(staffMeta);
		inv.setItem(19, staff);
		lore.clear();
		
		Main.gameInfo.put(inv, new BukkitRunnable() {
			public void run() {
				ItemStack timer = new ItemStack (Material.WATCH);
				ItemMeta timerMeta = timer.getItemMeta();
				timerMeta.setDisplayName("�8� �6Timers �8�");
				lore.add(" ");
				
				if (Game.getInstance().isRecordedRound()) {
					lore.add("�8� �7Current Episode: �a" + Timers.meetup);
					lore.add("�8� �7Time to next episode: �a" + Timers.time + " mins");
				}
				else if (GameUtils.getTeamSize().startsWith("No") || GameUtils.getTeamSize().startsWith("Open")) {
					lore.add("�8� �7There are no matches running.");
				}
				else if (!State.isState(State.INGAME)) {
					lore.add("�8� �7The game has not started yet.");
				}
				else {
					lore.add("�8� �7Time since start: �a" + DateUtils.ticksToString(Timers.timeSeconds));
					lore.add(Timers.pvpSeconds <= 0 ? "�8� �aPvP is enabled." : "�8� �7PvP in: �a" + DateUtils.ticksToString(Timers.pvpSeconds));
					lore.add(Timers.meetupSeconds <= 0 ? "�8� �6Meetup is now!" : "�8� �7Meetup in: �a" + DateUtils.ticksToString(Timers.meetupSeconds));
				}
				
				lore.add(" ");
				timerMeta.setLore(lore);
				timer.setItemMeta(timerMeta);
				inv.setItem(25, timer);
				lore.clear();
				player.updateInventory();
			}
		});
		
		Main.gameInfo.get(inv).runTaskTimer(Main.plugin, 1, 1);
		player.openInventory(inv);
		
		return inv;
	}
	
	/**
	 * Check if this slot shall have no items.
	 * 
	 * @param slot The slot.
	 * @return True if it shouldn't, false otherwise.
	 */
	private boolean noItem(int slot) {
		switch (slot) {
		case 0:
		case 8:
		case 9:
		case 17:
		case 18:
		case 26:
		case 27:
		case 35:
		case 36:
			return true;
		default:
			return false;
		}
	}
}
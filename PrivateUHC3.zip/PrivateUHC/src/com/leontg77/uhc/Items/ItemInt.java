package com.leontg77.uhc.Items;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import com.leontg77.uhc.InvGUI;
import com.leontg77.uhc.State;




public class ItemInt implements Listener {
	
	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
		
		Player player = e.getPlayer();
		ItemStack it = e.getItem();
		
		if(it == null) return;
		
		if(it.getType() == Material.GOLDEN_APPLE && it.hasItemMeta() && it.getItemMeta().hasDisplayName() 
				&& it.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �aUHC �8�")) {
			
			e.setCancelled(true);
			
			InvGUI inv = InvGUI.getInstance();
			inv.openGameInfo(player);
			
		}
		if(it.getType() == Material.REDSTONE_COMPARATOR && it.hasItemMeta() && it.getItemMeta().hasDisplayName() 
				&& it.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �cConfig �8�")) {
			
			e.setCancelled(true);
			
			InvGUI inv = InvGUI.getInstance();
			inv.openConfig(player);
			
		}
		
		
	}
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		
		Player p = e.getPlayer();
		
		ItemStack lr = new ItemStack(322, 1,(short)1);
		ItemMeta lrn = lr.getItemMeta();
		lrn.setDisplayName("�8� �aUHC �8�");
		lrn.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		lrn.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		lr.setItemMeta(lrn);
		
		
		ItemStack cr = new ItemStack(Material.REDSTONE_COMPARATOR);
		ItemMeta crn = cr.getItemMeta();
		crn.setDisplayName("�8� �cConfig �8�");
		crn.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		crn.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		cr.setItemMeta(crn);
		
		ItemStack pr = new ItemStack(Material.SIGN);
		ItemMeta prn = pr.getItemMeta();
		prn.setDisplayName("�8� �aScenarios �8�");
		prn.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		prn.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		pr.setItemMeta(prn);
		
		ItemStack diamond_sword = new ItemStack(Material.DIAMOND_SWORD);
		ItemMeta dr = diamond_sword.getItemMeta();
		dr.setDisplayName("�8� �aArena �8�");
		dr.spigot().setUnbreakable(true);
		dr.addEnchant(Enchantment.DAMAGE_UNDEAD, 1, true);
		dr.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
		dr.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		diamond_sword.setItemMeta(dr);
		
		
		
		if (State.isState(State.LOBBY)) {
		if(p.hasPermission("uhc.host"))		{	
		p.getInventory().clear();
		p.getInventory().setItem(0, diamond_sword);
		p.getInventory().setItem(3, lr);
		p.getInventory().setItem(5, pr);
		p.getInventory().setItem(8, cr);
		
		}else {
			p.getInventory().clear();
			p.getInventory().setItem(0, diamond_sword);
			p.getInventory().setItem(3, lr);
			p.getInventory().setItem(5, pr);
		}
		
		}
		
  
		
		
	}
	
	

}
